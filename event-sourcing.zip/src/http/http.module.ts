import { Module } from '@nestjs/common'
import { LambdaHTTPModule } from '@freebird/nest-lambda'
import { OfferClaimsController } from './http.controller'
import { OfferClaimsService } from './http.service'
import { DataModule } from '../core/data/data.module'
import { EventSourcingModule } from '../core/events/event-sourcing.module'
import { SeedModule } from '../core/data/seeds/seed.module'

@Module({
  imports: [LambdaHTTPModule, EventSourcingModule, DataModule, SeedModule],
  controllers: [OfferClaimsController],
  providers: [OfferClaimsService],
})
export class HttpModule {}
