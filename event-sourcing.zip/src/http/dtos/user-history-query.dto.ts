import { Transform } from 'class-transformer'
import {
  IsOptional,
  IsInt,
  IsIn,
  IsPositive,
  IsString,
  Max,
  ValidatorConstraint,
  ValidatorConstraintInterface,
  Validator,
  Validate,
  IsMongoId,
} from 'class-validator'
import {
  OfferClaimFilterableFieldsEnumObj,
  OfferClaimFilterableFields,
  OfferClaimSortablFieldsEnumObj,
  OfferClaimSortableFields,
} from '../../core/data/models/offer-claim.model'
import {
  IOfferClaimsSortTuple,
  IOfferClaimsHistoryFilterTuple,
  TOfferClaimsHistoryFilterableValue,
} from '../../core/data/repositories'
import { Types } from 'mongoose'

interface IQuerySortTuple {
  id: OfferClaimSortableFields
  desc: string
}

@ValidatorConstraint({ name: 'validateFilterTuples', async: false })
export class ValidateFilterTuples implements ValidatorConstraintInterface {
  private errorMessage = ''

  public validate(tuples: IOfferClaimsHistoryFilterTuple[]) {
    const foundInvalid = tuples.find(tuple => {
      let isInvalid = false

      switch (tuple.id) {
        case '_id':
        case 'locationId':
        case 'offerId':
        case 'transactionId':
        case 'tripId':
          isInvalid = !new Validator().isMongoId(tuple.value)

          if (isInvalid) {
            this.errorMessage = `${tuple.id} must be a mongodb id`
          }
          return isInvalid
        default:
          return false
      }
    })

    return foundInvalid ? false : true
  }

  public defaultMessage() {
    return this.errorMessage
  }
}

const transformFilterTupleTypes = (tuples: IOfferClaimsHistoryFilterTuple[]) => {
  return tuples.map(tuple => {
    if (tuple.id === 'createdAt') {
      tuple.value = new Date(tuple.value as string)
    }

    return tuple
  })
}

const transformSortTuple = (tuples: IQuerySortTuple[]): IOfferClaimsSortTuple[] => {
  return tuples.map(t => {
    return {
      id: t.id,
      desc: t.desc === 'false' ? false : true,
    }
  })
}

export class RouteParams {
  @IsMongoId()
  public userId: Types.ObjectId
}

class OfferClaimHistoryFilterTuple implements IOfferClaimsHistoryFilterTuple {
  @IsString()
  @IsIn(Object.keys(OfferClaimFilterableFieldsEnumObj))
  public id: OfferClaimFilterableFields

  @IsString()
  public value: TOfferClaimsHistoryFilterableValue
}

class OfferClaimSortTuple implements IOfferClaimsSortTuple {
  @IsIn(Object.keys(OfferClaimSortablFieldsEnumObj))
  public id: OfferClaimSortableFields

  @IsIn(['true', 'false'])
  public desc: boolean
}

export class UserHistoryQuery {
  @IsOptional()
  @Transform(v => parseInt(v, 10))
  @IsInt()
  @IsPositive()
  public page: number

  @IsOptional()
  @Transform(v => parseInt(v, 10))
  @IsInt()
  @IsPositive()
  @Max(100)
  public pageSize: number

  @IsOptional()
  @Transform(transformSortTuple)
  public sortBy?: OfferClaimSortTuple[]

  @IsOptional()
  @Validate(ValidateFilterTuples)
  @Transform(transformFilterTupleTypes)
  public filterBy?: OfferClaimHistoryFilterTuple[]
}
