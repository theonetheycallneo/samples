import { ClaimTypes, OfferClaimEventTypes } from '@freebird/contracts-offer-claims'
import {
  Equals,
  IsArray,
  IsBoolean,
  IsEnum,
  IsMongoId,
  IsNumber,
  IsString,
  IsOptional,
  IsObject,
  ValidateNested,
  ArrayMinSize,
} from 'class-validator'
import { Type, Transform } from 'class-transformer'
import { Types } from 'mongoose'

class OfferClaimMetaEstimatesDTO {
  @IsArray()
  @ValidateNested({ each: true })
  @ArrayMinSize(0)
  @Type(() => Object)
  public uber: any[]
  @IsArray()
  @ValidateNested({ each: true })
  @ArrayMinSize(0)
  @Type(() => Object)
  public lyft: any[]
}

class OfferClaimMetaReferringSourceDTO {
  @IsString()
  public id: string
  @IsString()
  public feature: string
  @IsString()
  public name: string
}

abstract class Offer {
  @IsBoolean()
  public isRedeemImmediately: boolean
  @IsEnum(ClaimTypes)
  public type: ClaimTypes
  @IsOptional()
  @IsEnum(OfferClaimEventTypes)
  @Transform(value => value || OfferClaimEventTypes.requested, { toClassOnly: true })
  public status?: OfferClaimEventTypes = OfferClaimEventTypes.requested
}

class BrandedAnywhereDTO extends Offer {
  @Equals(ClaimTypes.brandedAnywhere)
  public type: ClaimTypes.brandedAnywhere
  @IsObject()
  public campaign: object
  @IsObject()
  public googlePlace: object
  @IsString()
  public googlePlaceId: string
}

class PartnerDTO extends Offer {
  @IsMongoId()
  public locationId: Types.ObjectId
  @IsArray()
  public locationGeo: [number, number]
  @IsNumber()
  public locationServiceFee: number
  @IsNumber()
  public offerBudget: number
  @IsBoolean()
  public offerIsFreeTrial: boolean
}

class PartnerPaidDTO extends PartnerDTO {
  @Equals(ClaimTypes.partnerPaid)
  public type: ClaimTypes.partnerPaid
  @IsMongoId()
  public locationGroupId: Types.ObjectId
  @IsMongoId()
  public partnerId: Types.ObjectId
}

class PartnerSubsidizedDTO extends PartnerDTO {
  @Equals(ClaimTypes.partnerSubsidized)
  public type: ClaimTypes.partnerSubsidized
}

class BrandedPartnerDTO extends PartnerDTO {
  @Equals(ClaimTypes.brandedPartner)
  public type: ClaimTypes.brandedPartner
  @IsObject()
  public campaign: object
}

class GooglePlaceDTO extends Offer {
  @IsObject()
  public googlePlace: object
  @IsString()
  public googlePlaceId: string
}

class BrandedHomeDTO extends GooglePlaceDTO {
  @Equals(ClaimTypes.brandedHome)
  public type: ClaimTypes.brandedHome
  @IsObject()
  public campaign: object
}

class BrandedWorkDTO extends GooglePlaceDTO {
  @Equals(ClaimTypes.brandedWork)
  public type: ClaimTypes.brandedWork
  @IsObject()
  public campaign: object
}

class AnywhereDTO extends GooglePlaceDTO {
  @Equals(ClaimTypes.anywhere)
  public type: ClaimTypes.anywhere
}

class HomeDTO extends GooglePlaceDTO {
  @Equals(ClaimTypes.home)
  public type: ClaimTypes.home
}

class WorkDTO extends GooglePlaceDTO {
  @Equals(ClaimTypes.work)
  public type: ClaimTypes.work
}

type OfferDTO =
  | BrandedAnywhereDTO
  | BrandedPartnerDTO
  | BrandedHomeDTO
  | BrandedWorkDTO
  | AnywhereDTO
  | PartnerPaidDTO
  | PartnerSubsidizedDTO
  | HomeDTO
  | WorkDTO

export class OfferClaimMetaDTO {
  @ValidateNested()
  @Type(() => OfferClaimMetaEstimatesDTO)
  public estimates: OfferClaimMetaEstimatesDTO
  @ValidateNested()
  @Type(() => OfferClaimMetaReferringSourceDTO)
  public referringSource: OfferClaimMetaReferringSourceDTO
}

export enum OperatingSystem {
  android = 'android',
  ios = 'ios',
}

export class UnexpireOfferClaimsDTO {
  @IsMongoId({ each: true })
  public claimIds: Types.ObjectId[]
}

export class SessionDTO {
  @IsString()
  public appVersion: string
  @IsString()
  public distinctId: string
  @IsEnum(OperatingSystem)
  public os: OperatingSystem
  @IsNumber()
  public userLatitude: number
  @IsNumber()
  public userLongitude: number
}

export class OfferClaimPostPayloadDTO {
  @IsString()
  public destinationAddress: string
  @IsString()
  public destinationName: string
  @IsNumber()
  public destinationLatitude: number
  @IsNumber()
  public destinationLongitude: number

  @IsOptional()
  @IsBoolean()
  public inTerritory = true

  @IsBoolean()
  public isSandbox: boolean

  @ValidateNested()
  @Type(() => OfferClaimMetaDTO)
  public meta: OfferClaimMetaDTO

  @ValidateNested()
  @Type(() => Offer, {
    discriminator: {
      property: 'type',
      subTypes: [
        { value: AnywhereDTO, name: ClaimTypes.anywhere },
        { value: BrandedAnywhereDTO, name: ClaimTypes.brandedAnywhere },
        { value: BrandedHomeDTO, name: ClaimTypes.brandedHome },
        { value: BrandedPartnerDTO, name: ClaimTypes.brandedPartner },
        { value: BrandedWorkDTO, name: ClaimTypes.brandedWork },
        { value: HomeDTO, name: ClaimTypes.home },
        { value: PartnerPaidDTO, name: ClaimTypes.partnerPaid },
        { value: PartnerSubsidizedDTO, name: ClaimTypes.partnerSubsidized },
        { value: WorkDTO, name: ClaimTypes.work },
      ],
    },
    keepDiscriminatorProperty: true,
  })
  public offer: OfferDTO
  @IsMongoId()
  public offerId: Types.ObjectId

  @IsNumber()
  public rewardCash: number
  @IsNumber()
  public rewardPoints: number

  @IsOptional()
  @ValidateNested()
  @Type(() => SessionDTO)
  public session: SessionDTO

  @IsOptional()
  @IsMongoId()
  public voucherId?: Types.ObjectId | null
}
