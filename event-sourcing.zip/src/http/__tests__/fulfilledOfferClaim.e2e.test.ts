import { createStubContext } from '@freebird/lambda-test-utils'
import { IRedeemVoucherRequestPayload } from '@freebird/contracts-vouchers'
import {
  IMatchedTransactionForRedemptionPayload,
  IOfferClaimTripMatchedPayload,
  IOfferClaimFulfilledPayload,
  IOfferClaimIssuedPayload,
  TripStates,
} from '@freebird/contracts-offer-claims'
import { ITripUpdatedPayload } from '@freebird/contracts-trips'
import { OfferClaimEventTypes } from '@freebird/contracts-offer-claims'
import { generateMockApiGatewayHeaders } from '@freebird/lambda-test-utils'
import { Logger } from '@freebird/logger'
import { INestApplication } from '@nestjs/common'
import { Test } from '@nestjs/testing'
import { getModelForClass } from '@typegoose/typegoose'
import AWSMock from 'aws-sdk-mock'
import AWS from 'aws-sdk'
import Mongoose, { Connection, Types } from 'mongoose'
import request from 'supertest'
import { MongoMemoryReplSet } from 'mongodb-memory-server-global'
import { setupApp, SERVICE_NAME } from '../index'
import { OfferClaimPostPayloadDTO } from '../dtos/offer-claims.dto'
import { HttpModule } from '../http.module'
import {
  OfferClaim,
  OfferClaimEvent,
  OfferClaimEventModel,
  OfferClaimModel,
} from '../../core/data/models'
import { MongoConfigService } from '../../core/data/mongo-config'
import { EventProcessor } from '../../core/events/event-processor'
import { IContext } from '../../core/interfaces/context.interface'
import { OfferClaimIssuedEvent } from '../../core/events/issued.event'
import { OfferClaimTripMatchedEvent } from '../../core/events/trip-matched.event'
import { OfferClaimFulfilledEvent } from '../../core/events/fulfilled.event'
import {
  postOfferClaimsFixture,
  tripsDroppedOffStateEvent,
  transactionConsumerPayload,
} from '../../core/data/fixtures'

process.env.NO_TRACE = 'true'
process.env.EVENT_BUS_STREAM_NAME = 'mock-bus'
process.env.ANALYTICS_BUS_STREAM_NAME = 'mock-name'
process.env.EVENT_BUS_STREAM_ARN = 'mock-arn'
process.env.HAPI_TOPIC = 'mock-topic'
jasmine.DEFAULT_TIMEOUT_INTERVAL = 600000

describe(SERVICE_NAME, () => {
  let app: INestApplication
  let eventProcessor: EventProcessor
  let mongoServer: MongoMemoryReplSet
  let offerClaimEventModel: OfferClaimEventModel
  let offerClaimModel: OfferClaimModel

  const mockMongoConfig = {
    async getConfig() {
      const mongoUri = await mongoServer.getConnectionString()
      // console.warn('mongoUri', mongoUri)
      return {
        useNewUrlParser: true,
        useUnifiedTopology: true,
        useCreateIndex: true,
        useFindAndModify: false,
        uri: mongoUri,
      }
    },
  }

  const mockEmit = jest.fn()
  const mockRetry = jest.fn()

  const ensureIndexes = async (nestApp: INestApplication) => {
    const connection: Connection = nestApp.get('DefaultTypegooseConnection')
    for (const modelName in connection.models) {
      if (connection.models.hasOwnProperty(modelName)) {
        const model = connection.models[modelName]
        await model.ensureIndexes()
      }
    }
  }

  beforeAll(async () => {
    AWSMock.setSDKInstance(AWS)

    mongoServer = new MongoMemoryReplSet({
      replSet: { storageEngine: 'wiredTiger' },
    })

    await mongoServer.waitUntilRunning()

    const module = await Test.createTestingModule({
      imports: [HttpModule],
    })
      .overrideProvider(MongoConfigService)
      .useValue(mockMongoConfig)
      .compile()

    app = module.createNestApplication()
    setupApp(app)
    await app.init()

    eventProcessor = app.get(EventProcessor)
    offerClaimEventModel = getModelForClass(OfferClaimEvent)
    offerClaimModel = getModelForClass(OfferClaim)
  })

  beforeEach(async () => {
    await ensureIndexes(app)
    AWSMock.mock('SNS', 'publish', (_params, callback) => {
      callback(undefined, 'success')
    })
    AWSMock.mock('Kinesis', 'putRecord', (_params, callback) => {
      callback(undefined, 'success')
    })
    AWSMock.mock('Lambda', 'invoke', (_params, callback) => {
      callback(undefined, 'success')
    })
    jest.mock('@freebird/event-transport', () => {
      return {
        EventTransport: () => {
          return {
            emit: mockEmit,
            retry: mockRetry,
          }
        },
      }
    })
    jest
      .spyOn(OfferClaimIssuedEvent.prototype as any, 'redeemVoucher')
      .mockImplementation((_context: IContext, _payload: IRedeemVoucherRequestPayload) => {
        return Promise.resolve()
      })
    jest
      .spyOn(OfferClaimIssuedEvent.prototype, 'putToTopic')
      .mockImplementation((_context: IContext, _payload: IOfferClaimIssuedPayload) => {
        return Promise.resolve()
      })
    jest
      .spyOn(OfferClaimTripMatchedEvent.prototype, 'putToTopic')
      .mockImplementation((_context: IContext, _payload: IOfferClaimTripMatchedPayload) => {
        return Promise.resolve()
      })
    jest
      .spyOn(OfferClaimFulfilledEvent.prototype, 'putToTopic')
      .mockImplementation((_context: IContext, _payload: IOfferClaimFulfilledPayload) => {
        return Promise.resolve()
      })
  })

  afterEach(async () => {
    jest.resetAllMocks()
    jest.restoreAllMocks()
    const connection: Mongoose.Connection = app.get('DefaultTypegooseConnection')
    if (connection) {
      await connection.dropDatabase()
    }
  })

  afterAll(async () => {
    AWSMock.restore()
    await app.close()
    await mongoServer.stop()
  })

  const postOfferClaim = async (mockData: OfferClaimPostPayloadDTO | object) => {
    const response = await request(app.getHttpServer())
      .post(`/${SERVICE_NAME}/`)
      .send(mockData)
      .set(generateMockApiGatewayHeaders())

    return response
  }

  describe('fulfilledOfferClaim', () => {
    test('that created offer-claim with transaction will fulfill', async () => {
      const response = await postOfferClaim(postOfferClaimsFixture)
      expect(response.status).toEqual(201)
      let countEvents = await offerClaimEventModel.countDocuments({}).exec()
      expect(countEvents).toEqual(2)
      const { body } = response
      const matchClaimPayload: ITripUpdatedPayload = { ...tripsDroppedOffStateEvent }
      matchClaimPayload.userId = body.userId
      matchClaimPayload.destinationGeo = body.destinationGeo
      await eventProcessor.matchClaim(
        { logger: new Logger(createStubContext()) },
        matchClaimPayload,
      )

      let offerClaim = await offerClaimModel.findOne({}).exec()
      expect(offerClaim).toBeDefined()
      const fulfillClaimPayload: IMatchedTransactionForRedemptionPayload = Object.assign(
        {},
        transactionConsumerPayload,
      )
      fulfillClaimPayload.claimId = offerClaim ? offerClaim._id : Types.ObjectId()

      await eventProcessor.fulfillClaim(
        { logger: new Logger(createStubContext()) },
        fulfillClaimPayload,
      )

      countEvents = await offerClaimEventModel.countDocuments({}).exec()
      expect(countEvents).toEqual(4)
      const offerClaims = await offerClaimModel.countDocuments({}).exec()
      expect(offerClaims).toEqual(1)

      offerClaim = await offerClaimModel.findOne({}).exec()

      if (offerClaim) {
        expect(offerClaim.status).toEqual(OfferClaimEventTypes.fulfilled)
      } else {
        throw new Error('OfferClaim not found')
      }
    })
  })

  test('that offer-claims do not fulfill without a trip completed', async () => {
    const response = await postOfferClaim(postOfferClaimsFixture)
    expect(response.status).toEqual(201)
    let countEvents = await offerClaimEventModel.countDocuments({}).exec()
    expect(countEvents).toEqual(2)
    const { body } = response
    const matchClaimPayload: ITripUpdatedPayload = {
      ...tripsDroppedOffStateEvent,
      state: TripStates.rider_canceled,
    }
    matchClaimPayload.userId = body.userId
    matchClaimPayload.destinationGeo = body.destinationGeo
    await eventProcessor.matchClaim({ logger: new Logger(createStubContext()) }, matchClaimPayload)

    let offerClaim = await offerClaimModel.findOne({}).exec()
    expect(offerClaim).toBeDefined()
    const fulfillClaimPayload: IMatchedTransactionForRedemptionPayload = Object.assign(
      {},
      transactionConsumerPayload,
    )
    fulfillClaimPayload.claimId = offerClaim ? offerClaim._id : Types.ObjectId()

    await eventProcessor.fulfillClaim(
      { logger: new Logger(createStubContext()) },
      fulfillClaimPayload,
    )

    countEvents = await offerClaimEventModel.countDocuments({}).exec()
    expect(countEvents).toEqual(3)
    const offerClaims = await offerClaimModel.countDocuments({}).exec()
    expect(offerClaims).toEqual(1)

    offerClaim = await offerClaimModel.findOne({}).exec()

    if (offerClaim) {
      expect(offerClaim.status).toEqual(OfferClaimEventTypes.tripMatched)
    } else {
      throw new Error('OfferClaim not found')
    }
  })
})
