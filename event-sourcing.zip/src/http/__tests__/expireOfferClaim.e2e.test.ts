import AWSMock from 'aws-sdk-mock'
import AWS from 'aws-sdk'
import Mongoose, { Connection } from 'mongoose'
import request from 'supertest'
import { IRedeemVoucherRequestPayload } from '@freebird/contracts-vouchers'
import { OfferClaimEventTypes } from '@freebird/contracts-offer-claims'
import { IOfferClaimIssuedPayload, ClaimTypes } from '@freebird/contracts-offer-claims'
import { createStubContext, generateMockApiGatewayHeaders } from '@freebird/lambda-test-utils'
import { Logger } from '@freebird/logger'
import { INestApplication } from '@nestjs/common'
import { Test } from '@nestjs/testing'
import { getModelForClass } from '@typegoose/typegoose'
import { MongoMemoryReplSet } from 'mongodb-memory-server-global'
import { setupApp, SERVICE_NAME } from '../index'
import { OfferClaimPostPayloadDTO } from '../dtos/offer-claims.dto'
import { HttpModule } from '../http.module'
import {
  OfferClaim,
  OfferClaimEvent,
  OfferClaimEventModel,
  OfferClaimModel,
} from '../../core/data/models'
import { MongoConfigService } from '../../core/data/mongo-config'
import { EventProcessor } from '../../core/events/event-processor'
import { IContext } from '../../core/interfaces/context.interface'
import { OfferClaimIssuedEvent } from '../../core/events/issued.event'
import { postOfferClaimsFixture } from '../../core/data/fixtures'

process.env.NO_TRACE = 'true'
process.env.EVENT_BUS_STREAM_NAME = 'mock-bus'
process.env.EVENT_BUS_STREAM_ARN = 'mock-arn'
process.env.ANALYTICS_BUS_STREAM_NAME = 'mock-name'
process.env.HAPI_TOPIC = 'mock-topic'
process.env.REDEEM_VOUCHER_ARN = 'mock-voucher-arn'
jasmine.DEFAULT_TIMEOUT_INTERVAL = 600000

describe(SERVICE_NAME, () => {
  let app: INestApplication
  let eventProcessor: EventProcessor
  let mongoServer: MongoMemoryReplSet
  let offerClaimEventModel: OfferClaimEventModel
  let offerClaimModel: OfferClaimModel

  const mockMongoConfig = {
    async getConfig() {
      const mongoUri = await mongoServer.getConnectionString()
      // console.warn('mongoUri', mongoUri)
      return {
        useNewUrlParser: true,
        useUnifiedTopology: true,
        useCreateIndex: true,
        useFindAndModify: false,
        uri: mongoUri,
      }
    },
  }

  const context = createStubContext()
  const mockContext = {
    logger: new Logger(context),
  }
  const mockEmit = jest.fn()
  const mockRetry = jest.fn()

  const ensureIndexes = async (nestApp: INestApplication) => {
    const connection: Connection = nestApp.get('DefaultTypegooseConnection')
    for (const modelName in connection.models) {
      if (connection.models.hasOwnProperty(modelName)) {
        const model = connection.models[modelName]
        await model.ensureIndexes()
      }
    }
  }

  beforeAll(async () => {
    AWSMock.setSDKInstance(AWS)

    mongoServer = new MongoMemoryReplSet({
      replSet: { storageEngine: 'wiredTiger' },
    })

    await mongoServer.waitUntilRunning()

    const module = await Test.createTestingModule({
      imports: [HttpModule],
    })
      .overrideProvider(MongoConfigService)
      .useValue(mockMongoConfig)
      .compile()

    app = module.createNestApplication()
    setupApp(app)
    await app.init()

    eventProcessor = app.get(EventProcessor)
    offerClaimEventModel = getModelForClass(OfferClaimEvent)
    offerClaimModel = getModelForClass(OfferClaim)

    await ensureIndexes(app)
  })

  beforeEach(() => {
    AWSMock.mock('SNS', 'publish', (_params, callback) => {
      callback(undefined, 'success')
    })
    AWSMock.mock('Kinesis', 'putRecord', (_params, callback) => {
      callback(undefined, 'success')
    })
    AWSMock.mock('Lambda', 'invoke', (_params, callback) => {
      callback(undefined, 'success')
    })
    jest.mock('@freebird/event-transport', () => {
      return {
        EventTransport: () => {
          return {
            emit: mockEmit,
            retry: mockRetry,
          }
        },
      }
    })
  })

  afterEach(async () => {
    jest.resetAllMocks()
    jest.restoreAllMocks()
    const connection: Mongoose.Connection = app.get('DefaultTypegooseConnection')
    if (connection) {
      await connection.dropDatabase()
    }
  })

  afterAll(async () => {
    AWSMock.restore()
    await app.close()
    await mongoServer.stop()
  })

  const postOfferClaim = async (mockData: OfferClaimPostPayloadDTO | object) => {
    const response = await request(app.getHttpServer())
      .post(`/${SERVICE_NAME}/`)
      .send(mockData)
      .set(generateMockApiGatewayHeaders())

    return response
  }

  describe('POST /offer-claims', () => {
    test('offer-claim expired', async () => {
      const payload = { ...postOfferClaimsFixture }
      const spy = jest
        .spyOn(OfferClaimIssuedEvent.prototype as any, 'redeemVoucher')
        .mockImplementation((_context: IContext, _payload: IRedeemVoucherRequestPayload) => {
          return Promise.resolve()
        })
      const spyPutToTopic = jest
        .spyOn(OfferClaimIssuedEvent.prototype, 'putToTopic')
        .mockImplementation((_context: IContext, _payload: IOfferClaimIssuedPayload) => {
          return Promise.resolve()
        })
      const response = await postOfferClaim(payload)
      expect(response.status).toEqual(201)
      const countEvents = await offerClaimEventModel.countDocuments({}).exec()
      expect(countEvents).toEqual(2)
      const offerClaim = await offerClaimModel.findOne({}).exec()
      expect(offerClaim).toBeDefined()

      const { body } = response
      if (body && offerClaim) {
        const { _id: claimId } = offerClaim
        expect(body._id).toEqual(claimId.toString())
        expect(body.locationId).toEqual(payload.offer.locationId.toString())
        expect(body.locationGroupId).toEqual(payload.offer.locationGroupId.toString())
        expect(body.offerId).toEqual(payload.offerId.toString())
        expect(body.partnerId).toEqual(payload.offer.partnerId.toString())
        expect(body.rewardCash).toEqual(payload.rewardCash)
        expect(body.rewardPoints).toEqual(payload.rewardPoints)
        expect(body.status).toEqual(OfferClaimEventTypes.inspected)
        expect(body.type).toEqual(ClaimTypes.partnerPaid)
        expect(body.userId.toString().length).toBeGreaterThan(1)
        await eventProcessor.expireClaim(mockContext, {
          claimId,
        })
        const expiredClaim = await offerClaimModel.findOne({ _id: claimId }).exec()
        if (expiredClaim) {
          expect(expiredClaim.status).toEqual(OfferClaimEventTypes.expired)
        } else {
          throw new Error('OfferClaim not found')
        }
      } else {
        throw new Error('OfferClaim not found')
      }

      spy.mockReset()
      spyPutToTopic.mockReset()
    })
  })
})
