import 'source-map-support/register'

import { Logger } from '@freebird/logger'
import { CoreLogger } from '@freebird/nest-lambda'
import { NestFactory } from '@nestjs/core'
import { ValidationPipe, INestApplication } from '@nestjs/common'
import { ExpressAdapter } from '@nestjs/platform-express'
import { SwaggerModule, DocumentBuilder } from '@nestjs/swagger'
import { Context, Handler } from 'aws-lambda'
import { createServer, proxy } from 'aws-serverless-express'
import { eventContext } from 'aws-serverless-express/middleware'
import { Server } from 'http'
import express from 'express'
import { HttpModule } from './http.module'
import { DataModule } from '../core/data/data.module'

let cachedServer: Server
const expressApp = express()

export const SERVICE_NAME = 'offer-claims'

// NOTE: If you get ERR_CONTENT_DECODING_FAILED in your browser, this is likely
// due to a compressed response (e.g. gzip) which has not been handled correctly
// by aws-serverless-express and/or API Gateway. Add the necessary MIME types to
// binaryMimeTypes below
const binaryMimeTypes: string[] = []

export const setupApp = (app: INestApplication) => {
  app.setGlobalPrefix(SERVICE_NAME)
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      transform: true,
      disableErrorMessages: process.env.STAGE === 'prod',
    }),
  )

  app.enableCors()
  app.use(eventContext())

  const swaggerOptions = new DocumentBuilder()
    .setTitle('offer-claims Service')
    .setDescription('offer-claims service')
    .setVersion('1.0')
    .addTag(SERVICE_NAME)
    .setBasePath(`/${SERVICE_NAME}`)
    .build()

  const swaggerDoc = SwaggerModule.createDocument(app, swaggerOptions)

  SwaggerModule.setup(`${SERVICE_NAME}/api`, app, swaggerDoc)
}

async function bootstrapServer(lambdaContext: Context): Promise<Server> {
  const adapter = new ExpressAdapter(expressApp)
  const logger = new CoreLogger()
  const nestApp = await NestFactory.create(HttpModule, adapter, {
    logger,
    cors: {
      origin: '*',
      methods: 'GET,HEAD,PUT,PATCH,POST,DELETE,OPTIONS',
      credentials: true,
      preflightContinue: false,
      optionsSuccessStatus: 204,
    },
  })
  setupApp(nestApp)
  await nestApp.init()
  const data = nestApp.get(DataModule)
  await data.logModelIndexes({ logger: new Logger(lambdaContext) })
  return createServer(expressApp, undefined, binaryMimeTypes)
}

export const handler: Handler = async (event: any, lambdaContext: Context) => {
  lambdaContext.callbackWaitsForEmptyEventLoop = false

  if (!cachedServer) {
    cachedServer = await bootstrapServer(lambdaContext)
  }
  return proxy(cachedServer, event, lambdaContext, 'PROMISE').promise
}
