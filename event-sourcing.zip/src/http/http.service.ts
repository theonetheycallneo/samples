import { Injectable } from '@nestjs/common'
import { Types } from 'mongoose'
import { RepositoryProvider } from '../core/data/repositories'
import { UserHistoryQuery } from './dtos/user-history-query.dto'
import { IContext } from '../core/interfaces/context.interface'

type ObjectId = Types.ObjectId

@Injectable()
export class OfferClaimsService {
  constructor(private readonly repositories: RepositoryProvider) {}

  public async getOfferClaims(userId: ObjectId) {
    return await this.repositories.offerClaims.findByUserId(userId)
  }

  public getUserTripsByUserId(userId: Types.ObjectId, query: UserHistoryQuery, _ctx: IContext) {
    const params = Object.assign({}, query, { userId })
    return this.repositories.offerClaims.getPaginatedHistoryByUserId(params, _ctx)
  }

  public getOfferClaimById(claimId: ObjectId) {
    return this.repositories.offerClaims.findOneById(claimId)
  }
}
