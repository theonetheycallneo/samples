import { IAuthZ, AuthZ, APILoggingService, Roles, RolesGuard } from '@freebird/nest-lambda'
import {
  Body,
  Controller,
  Patch,
  Post,
  Delete,
  Param,
  Get,
  UseGuards,
  Query,
  ForbiddenException,
} from '@nestjs/common'
import { Types } from 'mongoose'
import { OfferClaimPostPayloadDTO, UnexpireOfferClaimsDTO } from './dtos/offer-claims.dto'
import { OfferClaimsService } from './http.service'
import { IContext } from '../core/interfaces/context.interface'
import { EventProcessor } from '../core/events/event-processor'
import { SeedService } from '../core/data/seeds/seed.service'
import { UserHistoryQuery, RouteParams } from './dtos/user-history-query.dto'
import { PortalUserRoles } from '@freebird/types-authz'

type IObjectId = Types.ObjectId

const { ObjectId } = Types
const logTarget = 'claims:http: '

interface IExpireOfferClaimParams {
  id: string
}

@UseGuards(RolesGuard)
@Controller()
export class OfferClaimsController {
  constructor(
    private readonly logger: APILoggingService,
    private readonly offerClaimsService: OfferClaimsService,
    private readonly processor: EventProcessor,
    private readonly seeder: SeedService,
    private readonly service: OfferClaimsService,
  ) {}

  @Post('/')
  public async createOfferClaim(@AuthZ() authZ: IAuthZ, @Body() dto: OfferClaimPostPayloadDTO) {
    const target = `${logTarget}createOfferClaim`
    const userId = ObjectId(authZ.id)
    const context = this.setupContext({ userId })
    const { logger } = context
    logger.debug(`${target} incoming request`, { dto: JSON.stringify(dto), userId })
    const offerClaim = await this.processor.requestClaim(context, {
      payload: dto,
      offerId: dto.offerId,
      userId,
    })
    return offerClaim
  }

  @Get('/')
  public async getOfferClaims(@AuthZ() authZ: IAuthZ) {
    const target = `${logTarget}createOfferClaim`
    const userId = ObjectId(authZ.id)
    const context = this.setupContext({ userId })
    const { logger } = context
    logger.debug(`${target} incoming request`, { userId })
    const claims = await this.service.getOfferClaims(userId)
    logger.debug(`${target} retrieved`, { claims, userId })
    return claims
  }

  @Get('/history/:userId')
  @Roles('admin', 'superadmin')
  public async getHistoryByUserId(
    @AuthZ() authZ: IAuthZ,
    @Param() params: RouteParams,
    @Query() query: UserHistoryQuery,
  ) {
    if (!authZ) {
      throw new ForbiddenException()
    }

    const ctx = this.setupContext({ userId: params.userId })

    return this.offerClaimsService.getUserTripsByUserId(params.userId, query, ctx)
  }

  @Post('admin/seeder/run')
  @Roles('admin', 'superadmin')
  public async runSeeder(@AuthZ() authZ: IAuthZ, @Body() dto: any) {
    const target = `${logTarget}runSeeder`
    const userId = ObjectId(authZ.id)
    const context = this.setupContext({ userId })
    const { logger } = context
    logger.debug(`${target} seedAll`, { dto, userId })
    await this.seeder.seedAll()
  }

  @Delete(':id/expire')
  @Roles('admin', 'superadmin')
  public async expireOfferClaim(@AuthZ() authZ: IAuthZ, @Param() params: IExpireOfferClaimParams) {
    const target = `${logTarget}expireOfferClaim`
    const userId = ObjectId(authZ.id)
    const context = this.setupContext({ userId })
    const { logger } = context
    logger.debug(`${target} incoming request`, { params, userId })
    const claimId = ObjectId(params.id)
    logger.mergeContext({
      'x-claims-claim-id': claimId.toString(),
    })
    const { offerClaim } = await this.processor.expireClaim(context, {
      claimId,
    })
    return offerClaim
  }

  @Patch(':id/unexpire')
  @Roles('admin', 'superadmin')
  public async unexpireOfferClaim(
    @AuthZ() authZ: IAuthZ,
    @Param() params: IExpireOfferClaimParams,
  ) {
    const target = `${logTarget}expireOfferClaim`
    const userId = ObjectId(authZ.id)
    const context = this.setupContext({ userId })
    const { logger } = context
    logger.debug(`${target} incoming request`, { params, userId })
    const claimId = ObjectId(params.id)
    logger.mergeContext({
      'x-claims-claim-id': claimId.toString(),
    })
    const { offerClaim } = await this.processor.unexpireClaim(context, {
      claimId,
    })
    return offerClaim
  }

  @Patch('unexpire')
  @Roles('admin', 'superadmin')
  public async unexpireOfferClaims(@AuthZ() authZ: IAuthZ, @Body() body: UnexpireOfferClaimsDTO) {
    const target = `${logTarget}expireOfferClaim`
    const userId = ObjectId(authZ.id)
    const context = this.setupContext({ userId })
    const { logger } = context
    logger.debug(`${target} incoming request`, { body, userId })
    return await Promise.all(
      body.claimIds.map(async claimId => {
        // logger.mergeContext({
        //   'x-claims-claim-id': claimId.toString(),
        // })
        const { offerClaim } = await this.processor.unexpireClaim(context, {
          claimId,
        })
        return offerClaim
      }),
    )
  }

  @Get(':claimId')
  @Roles(PortalUserRoles.ADMIN, PortalUserRoles.SUPER_ADMIN)
  public getClaimById(@Param('claimId') claimId: string) {
    return this.offerClaimsService.getOfferClaimById(ObjectId(claimId))
  }

  private setupContext(params: { userId: IObjectId }): IContext {
    const { logger } = this
    logger.mergeContext({
      'x-user-id': params.userId.toString(),
    })
    return { logger }
  }
}
