import { Logger } from '@freebird/events'
import { ITypegooseContext } from '@freebird/middy-typegoose'
import { INestApplicationContext } from '@nestjs/common'
import { NestFactory } from '@nestjs/core'
import { Context, Handler } from 'aws-lambda'
import { EventProcessor } from '../core/events/event-processor'
import { EventSourcingModule } from '../core/events/event-sourcing.module'
import { DataModule } from '../core/data/data.module'

type ILambdaContext = Context & ITypegooseContext

let nestApp: INestApplicationContext
let processor: EventProcessor

const logTarget = 'claims:crons:expiration: '

export const handler: Handler = async (lambdaEvent: any, lambdaContext: ILambdaContext) => {
  lambdaContext.callbackWaitsForEmptyEventLoop = false
  const target = `${logTarget}handler`
  const logger = new Logger(lambdaContext)
  const context = { logger }
  if (!nestApp) {
    logger.debug(`${target} creating nest application context`)
    nestApp = await NestFactory.createApplicationContext(EventSourcingModule)
    processor = nestApp.get(EventProcessor)
    const data = nestApp.get(DataModule)
    await data.logModelIndexes(context)
  }

  try {
    logger.debug(`${target} incoming cron lambda event`, { lambdaEvent })
    await processor.expireClaims(context)
    logger.debug(`${target} processed event succesfully`, { lambdaEvent })
  } catch (error) {
    const { message } = error
    logger.warn(`${target} ${message}, cron will naturally retry...`, { error })
  }
}
