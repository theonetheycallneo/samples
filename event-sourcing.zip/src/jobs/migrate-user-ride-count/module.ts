import { Module } from '@nestjs/common'
import { DataModule } from '../../core/data/data.module'
@Module({
  imports: [DataModule],
})
export class MigrateUserRideCount {}
