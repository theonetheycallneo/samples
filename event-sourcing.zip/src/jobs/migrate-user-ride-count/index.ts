/* tslint:disable:no-console */

import { INestApplicationContext } from '@nestjs/common'
import { Context } from 'aws-lambda'
import { NestFactory } from '@nestjs/core'
import assert from 'assert'
import { MongoClient } from 'mongodb'
import pLimit from 'p-limit'

import { MigrateUserRideCount } from './module'
import { UserStatsRepository } from '../../core/data/repositories'
let nestApp: INestApplicationContext
const limit = pLimit(400)

export const handler = async (_lambdaEvent: any, _lambdaContext: Context) => {
  assert(process.env.MONGO_URI_STRING, 'You need to export a MONGO_URI_STRING env var')

  const uri = process.env.MONGO_URI_STRING ? process.env.MONGO_URI_STRING : ''

  let processedCount = 0
  let loadedIntoMemory = 0
  const LIMIT = 10000

  const sleep = (time: number) => new Promise(resolve => setTimeout(resolve, time))
  const client = new MongoClient(uri)
  await client.connect()
  console.log('Connected to Mongo')

  const db = client.db('hapi')
  const usersCollection = db.collection('users')
  const ridesCollection = db.collection('rides')
  if (!nestApp) {
    nestApp = await NestFactory.createApplicationContext(MigrateUserRideCount)
  }

  const userStatsRepo = nestApp.get(UserStatsRepository)

  const onSingleUserComplete = () => {
    processedCount++
    const percentComplete = (processedCount / userCount) * 100
    console.log(
      `Processed ${processedCount} users of ${userCount}. ${loadedIntoMemory} Loaded into memory. ${percentComplete.toFixed(
        2,
      )}% Complete.`,
    )
  }

  const migrateCode = async (user: any) => {
    await limit(async () => {
      try {
        const rideCount = await ridesCollection.count({ user: user._id, status: { $gte: 5 } })
        const userStats = await userStatsRepo.findOneById(user._id)
        if (userStats) {
          await userStatsRepo.findOneAndUpdate(user._id, { $set: { legacyRideCount: rideCount } })
        } else {
          await userStatsRepo.findOneAndUpdate(user._id, {
            $set: {
              _id: user._id,
              legacyRideCount: rideCount,
              fulfilledCount: 0,
              fulfilledInTerritoryCount: 0,
            },
          })
        }
        console.log('legacyRideCount created')
      } catch (_err) {
        console.log('Error')
      }
    }).then(() => onSingleUserComplete())
  }

  const users = usersCollection.find({})

  const userCount = await users.count()

  console.log(`User Count: ${userCount}`)
  while (await users.hasNext()) {
    const u = await users.next()
    loadedIntoMemory++

    if (loadedIntoMemory > LIMIT) {
      await sleep(12000)
      loadedIntoMemory = 0
    }
    // remove await when running
    await migrateCode(u)
  }

  await sleep(60000)
  await client.close()
  console.log(`Connection has been closed`)
}
