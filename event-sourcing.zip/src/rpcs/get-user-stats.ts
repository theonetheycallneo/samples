import { Context } from 'aws-lambda'
import { Logger } from '@freebird/logger'
import { decodeLambdaRPC } from '@freebird/events'
import {
  GetOfferClaimUserStatsRequest,
  GetOfferClaimUserStatsResponse,
  IGetOfferClaimUserStatsRequestPayload,
} from '@freebird/contracts-offer-claims'
import { INestApplicationContext } from '@nestjs/common'
import { NestFactory } from '@nestjs/core'
import warmer from 'lambda-warmer'
import { DataModule } from '../core/data/data.module'
import { UserStatsRepository } from '../core/data/repositories'

let app: INestApplicationContext

const logTarget = 'claims:get-user-stats: '

export const handler = async (lambdaEvent: any, lambdaContext: Context) => {
  if (!app) {
    app = await NestFactory.createApplicationContext(DataModule)
  }

  if (await warmer(lambdaEvent)) {
    return 'warmed'
  }

  const service = app.get(UserStatsRepository)

  const target = `${logTarget}getApplicationContext`
  const preDecodeLogger = new Logger(lambdaContext)
  preDecodeLogger.debug(`${target} pre-decoded incoming event`, { lambdaEvent })

  const { payload, log } = await decodeLambdaRPC<IGetOfferClaimUserStatsRequestPayload>(
    lambdaEvent,
    lambdaContext,
    GetOfferClaimUserStatsRequest,
  )

  log.debug(`${target} decoded incoming event`, { payload })

  const { userId } = payload
  const user = await service.findOneById(userId)
  let response
  if (user) {
    const { fulfilledCount, fulfilledInTerritoryCount } = user
    response = new GetOfferClaimUserStatsResponse({
      fulfilledCount,
      fulfilledInTerritoryCount,
    })
  } else {
    response = new GetOfferClaimUserStatsResponse({
      fulfilledCount: 0,
      fulfilledInTerritoryCount: 0,
    })
  }
  log.debug(`${target} outgoing response`, { response })

  return response
}
