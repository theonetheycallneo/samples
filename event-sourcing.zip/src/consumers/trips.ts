import { processFor } from '@freebird/events'
import { ITripUpdatedPayload, TripUpdated } from '@freebird/contracts-trips'
import { ITypegooseContext } from '@freebird/middy-typegoose'
import { NestFactory } from '@nestjs/core'
import { INestApplicationContext } from '@nestjs/common'
import { Context, SQSEvent } from 'aws-lambda'
import { EventProcessor } from '../core/events/event-processor'
import { EventSourcingModule } from '../core/events/event-sourcing.module'
import { DataModule } from '../core/data/data.module'

type ITripEventContext = Context & ITypegooseContext

let nestApp: INestApplicationContext
let processor: EventProcessor

const logTarget = 'claims:consumers:trips: '

export const handler = async (lambdaEvent: SQSEvent, lambdaContext: ITripEventContext) => {
  lambdaContext.callbackWaitsForEmptyEventLoop = false
  const target = `${logTarget}handler`
  await processFor<ITripUpdatedPayload>(lambdaEvent, lambdaContext, TripUpdated, {
    handler: async event => {
      event.log.debug(`${target} incoming event`, { event })
      const context = { logger: event.log }
      if (!nestApp) {
        event.log.debug(`${target} creating nest application context`)
        nestApp = await NestFactory.createApplicationContext(EventSourcingModule)
        processor = nestApp.get(EventProcessor)
        const data = nestApp.get(DataModule)
        await data.logModelIndexes(context)
      }

      const { payload } = event
      await processor.matchClaim(context, payload)
      event.log.debug(`${target} processed event succesfully`, { event, payload })
    },
  })
}
