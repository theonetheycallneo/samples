import { processFor, RecordSources } from '@freebird/events'
import { ITripUpdatedPayload, TripUpdated } from '@freebird/contracts-trips'
import { EventTransport } from '@freebird/event-transport'
import { ITypegooseContext } from '@freebird/middy-typegoose'
import { NestFactory } from '@nestjs/core'
import { INestApplicationContext } from '@nestjs/common'
import { Context, SQSEvent } from 'aws-lambda'
import { EventProcessor } from '../core/events/event-processor'
import { EventSourcingModule } from '../core/events/event-sourcing.module'
import { DataModule } from '../core/data/data.module'

type ITripEventContext = Context & ITypegooseContext

let nestApp: INestApplicationContext
let processor: EventProcessor

const logTarget = 'claims:crons:expiration: '

export const handler = async (lambdaEvent: SQSEvent, lambdaContext: ITripEventContext) => {
  lambdaContext.callbackWaitsForEmptyEventLoop = false
  const target = `${logTarget}handler`
  await processFor<ITripUpdatedPayload>(lambdaEvent, lambdaContext, TripUpdated, {
    handler: async event => {
      event.log.debug(`${target} incoming event`, { event })
      try {
        const context = { logger: event.log }
        if (!nestApp) {
          event.log.debug(`${target} creating nest application context`)
          nestApp = await NestFactory.createApplicationContext(EventSourcingModule)
          processor = nestApp.get(EventProcessor)
          const data = nestApp.get(DataModule)
          await data.logModelIndexes(context)
        }

        const { payload } = event
        event.log.debug(`${target} incoming payload`, { payload })
        await processor.matchClaim(context, payload)
        event.log.debug(`${target} processed event sucessfully`, { event })
      } catch (error) {
        const { message } = error
        event.log.warn(`${target} ${message}, retrying...`, { error })
        if (event.recordSource === RecordSources.SNS) {
          throw error
        } else {
          const eventTransport = new EventTransport(event.log)

          if (!process.env.RETRY_TOPIC) {
            const retryMessage = `${target} missing env config`
            event.log.error(retryMessage, { missingConfig: 'RETRY_TOPIC' })
            throw new Error(retryMessage)
          }

          await eventTransport.retry({
            to: process.env.RETRY_TOPIC,
            event,
          })
        }
      }
    },
  })
}
