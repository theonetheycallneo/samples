import { NestFactory } from '@nestjs/core'
import { INestApplicationContext } from '@nestjs/common'
import { processFor } from '@freebird/events'
import {
  MatchedTransactionForRedemption,
  IMatchedTransactionForRedemptionPayload,
} from '@freebird/contracts-offer-claims'
import { ITypegooseContext } from '@freebird/middy-typegoose'
import { Context, SQSEvent } from 'aws-lambda'
import { DataModule } from '../core/data/data.module'
import { EventProcessor } from '../core/events/event-processor'
import { EventSourcingModule } from '../core/events/event-sourcing.module'

type ITripEventContext = Context & ITypegooseContext

let nestApp: INestApplicationContext
let processor: EventProcessor

const logTarget = 'claims:consumers:transactions: '

export const handler = async (lambdaEvent: SQSEvent, lambdaContext: ITripEventContext) => {
  lambdaContext.callbackWaitsForEmptyEventLoop = false
  const target = `${logTarget}handler`
  await processFor<IMatchedTransactionForRedemptionPayload>(
    lambdaEvent,
    lambdaContext,
    MatchedTransactionForRedemption,
    {
      handler: async event => {
        event.log.debug(`${target} incoming event`, { event })
        const context = { logger: event.log }
        if (!nestApp) {
          event.log.debug(`${target} creating nest application context`)
          nestApp = await NestFactory.createApplicationContext(EventSourcingModule)
          processor = nestApp.get(EventProcessor)
          const data = nestApp.get(DataModule)
          await data.logModelIndexes(context)
        }
        const { payload } = event
        await processor.fulfillClaim(context, payload)
        event.log.debug(`${target} processed event succesfully`, { event, payload })
      },
    },
  )
}
