import { checkIndexes } from '@freebird/typegoose-utils'
import { Module } from '@nestjs/common'
import { TypegooseModule } from 'nestjs-typegoose'
import { OfferClaimEvent, OfferClaim, Territory, UserStats } from './models'
import { MongoConfigModule, MongoConfigService } from './mongo-config'
import { Repositories, RepositoryProvider } from './repositories'
import { IContext } from '../interfaces/context.interface'

const providers = [...Repositories, RepositoryProvider]
const models = [OfferClaimEvent, OfferClaim, Territory, UserStats]

@Module({
  imports: [
    TypegooseModule.forRootAsync({
      useFactory: async (config: MongoConfigService) => {
        return await config.getConfig()
      },
      imports: [MongoConfigModule],
      inject: [MongoConfigService],
    }),
    TypegooseModule.forFeature(models),
  ],
  exports: providers,
  controllers: [],
  providers,
})
export class DataModule {
  public async logModelIndexes(context: IContext) {
    const { logger } = context
    await checkIndexes(logger, models)
  }
}
