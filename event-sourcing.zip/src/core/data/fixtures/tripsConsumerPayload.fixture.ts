import { TripPlatform, TripStates } from '@freebird/contracts-trips'

export const tripsConsumerPayload = {
  event: {
    eventType: 'TRIP_UPDATED',
    payload: {
      platform: TripPlatform.uber,
      riderId:
        '8K04S4Eg__Mbnf5VYCvNZxPb3mEbKu7P_mv394sNjhyOrzrTWScjIHQJveI2VtS2CGwc8hKHhHQwvHDl6f2jjwd7dQdZvUcZhQJbDC6DUm5mYczXvSzYxpfPsO6TQSPAug==',
      tripId: '598472d7710880a8e787b999',
      userId: '598472d7710880a8e787b111',
      state: TripStates.droppedoff,
      createdAt: new Date(),
      updatedAt: new Date(),
      rideId: 'cbf9460b-5e9a-5da2-a155-d91bab3aa4a5',
      destinationGeo: [-118.4777129, 33.9963886],
      pickupGeo: [-118.478337, 33.997495],
      productName: 'UberX',
    },
  },
}
