import { Types } from 'mongoose'

export const transactionConsumerPayload = {
  claimId: Types.ObjectId(),
  transactionId: Types.ObjectId(),
  transactionMatchedDate: new Date(),
  transactionTotal: 10,
}
