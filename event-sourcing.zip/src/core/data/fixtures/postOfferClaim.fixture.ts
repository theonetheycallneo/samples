import { ClaimTypes } from '@freebird/contracts-offer-claims'
import { Types } from 'mongoose'
import { lyftEstimates } from '../models/fixtures/lyft-estimates'
import { uberEstimates } from '../models/fixtures/uber-estimates'

export const postOfferClaimsFixture = {
  destinationAddress: '123 Main St',
  destinationLatitude: 34.0522,
  destinationLongitude: -118.2437,
  destinationName: '123',
  isSandbox: false,
  offer: {
    isRedeemImmediately: false,
    locationId: Types.ObjectId(),
    locationGeo: [-118.2437, 34.0522],
    locationGroupId: Types.ObjectId(),
    locationServiceFee: 2.7,
    offerBudget: 50,
    offerIsFreeTrial: false,
    partnerId: Types.ObjectId(),
    type: ClaimTypes.partnerPaid,
  },
  offerId: Types.ObjectId(),
  meta: {
    estimates: {
      lyft: lyftEstimates,
      uber: uberEstimates,
    },
    referringSource: {
      id: '598472d6710880a8e787b07e',
      feature: 'Search Recent Rides',
      name: 'GooglePlaceId',
    },
  },
  rewardCash: 4,
  rewardPoints: 0,
  session: {
    appVersion: '7.0.0',
    distinctId: '1234567890',
    os: 'ios',
    userLatitude: 34.054,
    userLongitude: -118.2455,
  },
  voucherId: null,
}

export const postOfferClaimsRedeemImmediately = {
  destinationAddress: '123 Main St',
  destinationLatitude: 34.0522,
  destinationLongitude: -118.2437,
  destinationName: '123',
  isSandbox: false,
  offer: {
    googlePlaceId: '123',
    googlePlace: {},
    isRedeemImmediately: false,
    type: ClaimTypes.anywhere,
  },
  offerId: Types.ObjectId(),
  meta: {
    estimates: {
      lyft: lyftEstimates,
      uber: uberEstimates,
    },
    referringSource: {
      id: '598472d6710880a8e787b07e',
      feature: 'Branded Ride Home',
      name: 'GooglePlaceId',
    },
  },
  rewardCash: 4,
  rewardPoints: 0,
  session: {
    appVersion: '7.0.0',
    distinctId: '1234567890',
    os: 'ios',
    userLatitude: 34.054,
    userLongitude: -118.2455,
  },
  voucherId: null,
}
