import { Types } from 'mongoose'
import { TripPlatform, TripStates, ITripUpdatedPayload } from '@freebird/contracts-trips'

export const tripsDroppedOffStateEvent: ITripUpdatedPayload = {
  createdAt: new Date(),
  destinationGeo: [-118.4777129, 33.9963886],
  isReceiptReceived: false,
  pickupGeo: [-118.478337, 33.997495],
  platform: TripPlatform.uber,
  productName: 'UberX',
  riderId:
    '8K04S4Eg__Mbnf5VYCvNZxPb3mEbKu7P_mv394sNjhyOrzrTWScjIHQJveI2VtS2CGwc8hKHhHQwvHDl6f2jjwd7dQdZvUcZhQJbDC6DUm5mYczXvSzYxpfPsO6TQSPAug==',
  state: TripStates.droppedoff,
  rideId: 'cbf9460b-5e9a-5da2-a155-d91bab3aa4a5',
  tripId: Types.ObjectId(),
  updatedAt: new Date(),
  userId: Types.ObjectId(),
}
