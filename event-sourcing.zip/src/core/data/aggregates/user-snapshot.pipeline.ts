import { OfferClaimEventTypes } from '@freebird/contracts-offer-claims'
import { IUserSnapshotAggregateParameters } from '../repositories'

export const getUserSnapshotPipeline = (params: IUserSnapshotAggregateParameters) => {
  const { userId } = params
  const updatedAt = new Date()
  return [
    {
      $match: {
        userId,
        status: OfferClaimEventTypes.fulfilled,
      },
    },
    { $sort: { createdAt: 1 } },
    {
      $group: {
        _id: {
          userId: '$userId',
        },
        fulfilledCount: { $sum: 1 },
        fulfilledInTerritoryCount: {
          $sum: {
            $switch: {
              branches: [
                {
                  case: { $eq: ['$inTerritory', true] },
                  then: 1,
                },
              ],
              default: 0,
            },
          },
        },
        legacyRideCount: { $first: 1 },
      },
    },
    {
      $project: {
        _id: { $toObjectId: userId.toString() },
        fulfilledCount: { $add: ['$fulfilledCount', '$legacyRideCount'] },
        fulfilledInTerritoryCount: { $add: ['$fulfilledInTerritoryCount', '$legacyRideCount'] },
        legacyRideCount: 1,
        updatedAt,
      },
    },
    {
      $merge: {
        into: 'userstats',
        on: ['_id'],
        whenMatched: 'replace',
        whenNotMatched: 'insert',
      },
    },
  ]
}
