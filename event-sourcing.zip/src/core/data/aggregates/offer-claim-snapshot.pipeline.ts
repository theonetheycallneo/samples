import { OfferClaimEventTypes } from '@freebird/contracts-offer-claims'
import { IOfferClaimSnapshotAggregateParameters } from '../repositories'

const { expired, tripMatched, fulfilled, unexpired } = OfferClaimEventTypes

const enforceStatus = (input: string) => {
  return {
    $switch: {
      branches: [
        {
          case: {
            $and: [
              { $in: [expired, '$eventTypes'] },
              { $not: { $in: [unexpired, '$eventTypes'] } },
            ],
          },
          then: expired,
        },
        {
          case: { $in: [fulfilled, '$eventTypes'] },
          then: fulfilled,
        },
        {
          case: { $in: [tripMatched, '$eventTypes'] },
          then: tripMatched,
        },
      ],
      default: input,
    },
  }
}

const filterType = (input: string, type: OfferClaimEventTypes) => {
  return {
    $filter: {
      input,
      as: 'f',
      cond: { $eq: ['$$f', type] },
    },
  }
}

const filterLastNonNull = (input: string) => {
  return {
    $filter: {
      input,
      as: 'f',
      cond: { $ne: ['$$f', null] },
    },
  }
}

const getFirstElement = (input: string) => {
  return { $arrayElemAt: [input, 0] }
}

const getLastElement = (input: string) => {
  return { $arrayElemAt: [input, -1] }
}

export const getOfferClaimSnapshotPipeline = (params: IOfferClaimSnapshotAggregateParameters) => {
  const { claimId } = params
  const updatedAt = new Date()
  return [
    {
      $match: {
        claimId,
      },
    },
    { $sort: { createdAt: 1 } },
    {
      $group: {
        _id: {
          claimId: '$claimId',
        },
        campaign: { $push: '$payload.offer.campaign' },
        createdAt: { $push: '$createdAt' },
        destinationAddress: { $push: '$payload.destinationAddress' },
        destinationLatitude: { $push: '$payload.destinationLatitude' },
        destinationLongitude: { $push: '$payload.destinationLongitude' },
        destinationName: { $push: '$payload.destinationName' },
        expiresAt: { $push: '$expiresAt' },
        googlePlace: { $push: '$payload.offer.googlePlace' },
        googlePlaceId: { $push: '$payload.offer.googlePlaceId' },
        inTerritory: { $push: '$payload.inTerritory' },
        isReceiptReceived: { $push: '$payload.isReceiptReceived' },
        isRedeemImmediately: { $push: '$payload.offer.isRedeemImmediately' },
        isSandbox: { $push: '$payload.isSandbox' },
        locationGeo: { $push: '$payload.offer.locationGeo' },
        locationGroupId: { $push: '$payload.offer.locationGroupId' },
        locationId: { $push: '$payload.offer.locationId' },
        locationServiceFee: { $push: '$payload.offer.locationServiceFee' },
        offerBudget: { $push: '$payload.offer.offerBudget' },
        offerId: { $push: '$payload.offerId' },
        offerIsFreeTrial: { $push: '$payload.offer.offerIsFreeTrial' },
        partnerId: { $push: '$payload.offer.partnerId' },
        payloads: { $push: '$payload' },
        pickupGeo: { $push: '$payload.pickupGeo' },
        referringSource: { $push: '$payload.meta.referringSource' },
        rewardCash: { $push: '$payload.rewardCash' },
        rewardPoints: { $push: '$payload.rewardPoints' },
        session: { $push: '$payload.session' },
        status: { $push: '$eventType' },
        transactionAmount: { $push: '$payload.transactionTotal' },
        transactionId: { $push: '$payload.transactionId' },
        tripId: { $push: '$payload.tripId' },
        tripMatchedDate: { $push: '$payload.tripMatchedDate' },
        tripPlatform: { $push: '$payload.platform' },
        tripState: { $push: '$payload.state' },
        type: { $push: '$payload.offer.type' },
        userId: { $push: '$userId' },
        voucherId: { $push: '$payload.voucherId' },
        voucherRedemptionId: { $push: '$payload.voucherRedemptionId' },
      },
    },
    {
      $project: {
        campaign: filterLastNonNull('$campaign'),
        createdAt: filterLastNonNull('$createdAt'),
        destinationAddress: filterLastNonNull('$destinationAddress'),
        destinationLatitude: filterLastNonNull('$destinationLatitude'),
        destinationLongitude: filterLastNonNull('$destinationLongitude'),
        destinationName: filterLastNonNull('$destinationName'),
        expiresAt: filterLastNonNull('$expiresAt'),
        googlePlace: filterLastNonNull('$googlePlace'),
        googlePlaceId: filterLastNonNull('$googlePlaceId'),
        inTerritory: filterLastNonNull('$inTerritory'),
        isExpired: filterType('$status', expired),
        isFulfilled: filterType('$status', fulfilled),
        isUnexpired: filterType('$status', unexpired),
        isReceiptReceived: filterLastNonNull('$isReceiptReceived'),
        isRedeemImmediately: filterLastNonNull('$isRedeemImmediately'),
        isSandbox: filterLastNonNull('$isSandbox'),
        isTripMatched: filterType('$status', tripMatched),
        locationGeo: filterLastNonNull('$locationGeo'),
        locationGroupId: filterLastNonNull('$locationGroupId'),
        locationId: filterLastNonNull('$locationId'),
        locationServiceFee: filterLastNonNull('$locationServiceFee'),
        offerBudget: filterLastNonNull('$offerBudget'),
        offerId: filterLastNonNull('$offerId'),
        offerIsFreeTrial: filterLastNonNull('$offerIsFreeTrial'),
        partnerId: filterLastNonNull('$partnerId'),
        payloads: filterLastNonNull('$payloads'),
        pickupGeo: filterLastNonNull('$pickupGeo'),
        referringSource: filterLastNonNull('$referringSource'),
        rewardCash: filterLastNonNull('$rewardCash'),
        rewardPoints: filterLastNonNull('$rewardPoints'),
        session: filterLastNonNull('$session'),
        status: filterLastNonNull('$status'),
        transactionAmount: filterLastNonNull('$transactionAmount'),
        transactionId: filterLastNonNull('$transactionId'),
        tripId: filterLastNonNull('$tripId'),
        tripMatchedDate: filterLastNonNull('$tripMatchedDate'),
        tripPlatform: filterLastNonNull('$tripPlatform'),
        tripState: filterLastNonNull('$tripState'),
        type: filterLastNonNull('$type'),
        userId: filterLastNonNull('$userId'),
        voucherId: '$voucherId',
        voucherRedemptionId: '$voucherRedemptionId',
      },
    },
    {
      $project: {
        campaign: getLastElement('$campaign'),
        createdAt: getFirstElement('$createdAt'),
        expiresAt: getLastElement('$expiresAt'),
        eventTypes: '$status',
        destinationAddress: getLastElement('$destinationAddress'),
        destinationLatitude: getLastElement('$destinationLatitude'),
        destinationLongitude: getLastElement('$destinationLongitude'),
        destinationName: getLastElement('$destinationName'),
        inTerritory: getLastElement('$inTerritory'),
        isExpired: {
          $and: [{ $in: [expired, '$status'] }, { $not: { $in: [unexpired, '$status'] } }],
        },
        isUnexpired: {
          $cond: {
            if: { $gt: [{ $size: '$isUnexpired' }, 0] },
            then: true,
            else: false,
          },
        },
        isFulfilled: {
          $cond: {
            if: { $gt: [{ $size: '$isFulfilled' }, 0] },
            then: true,
            else: false,
          },
        },
        isTripMatched: {
          $cond: {
            if: { $gt: [{ $size: '$isTripMatched' }, 0] },
            then: true,
            else: false,
          },
        },
        googlePlace: getLastElement('$googlePlace'),
        googlePlaceId: getLastElement('$googlePlaceId'),
        isReceiptReceived: getLastElement('$isReceiptReceived'),
        isRedeemImmediately: getLastElement('$isRedeemImmediately'),
        isSandbox: getLastElement('$isSandbox'),
        locationGeo: getLastElement('$locationGeo'),
        locationGroupId: getLastElement('$locationGroupId'),
        locationId: getLastElement('$locationId'),
        locationServiceFee: getLastElement('$locationServiceFee'),
        offerBudget: getLastElement('$offerBudget'),
        offerId: getLastElement('$offerId'),
        offerIsFreeTrial: getLastElement('$offerIsFreeTrial'),
        partnerId: getLastElement('$partnerId'),
        payloads: 1,
        pickupGeo: getLastElement('$pickupGeo'),
        referringSource: getLastElement('$referringSource'),
        rewardCash: getLastElement('$rewardCash'),
        rewardPoints: getLastElement('$rewardPoints'),
        session: getLastElement('$session'),
        status: getLastElement('$status'),
        transactionAmount: getLastElement('$transactionAmount'),
        transactionId: getLastElement('$transactionId'),
        tripId: getLastElement('$tripId'),
        tripMatchedDate: getLastElement('$tripMatchedDate'),
        tripPlatform: getLastElement('$tripPlatform'),
        tripState: getLastElement('$tripState'),
        type: getLastElement('$type'),
        userId: getLastElement('$userId'),
        voucherId: getLastElement('$voucherId'),
        voucherRedemptionId: getLastElement('$voucherRedemptionId'),
      },
    },
    {
      $project: {
        _id: { $toObjectId: claimId.toString() },
        campaign: '$campaign',
        createdAt: 1,
        destinationAddress: '$destinationAddress',
        destinationGeo: ['$destinationLongitude', '$destinationLatitude'],
        destinationName: '$destinationName',
        expiresAt: 1,
        eventTypes: '$eventTypes',
        googlePlace: '$googlePlace',
        googlePlaceId: '$googlePlaceId',
        inTerritory: '$inTerritory',
        isExpired: 1,
        isFulfilled: 1,
        isUnexpired: 1,
        isReceiptReceived: '$isReceiptReceived',
        isRedeemImmediately: '$isRedeemImmediately',
        isSandbox: '$isSandbox',
        isTripMatched: 1,
        locationGeo: '$locationGeo',
        locationGroupId: { $toObjectId: '$locationGroupId' },
        locationId: { $toObjectId: '$locationId' },
        locationServiceFee: '$locationServiceFee',
        offerBudget: '$offerBudget',
        offerId: { $toObjectId: '$offerId' },
        offerIsFreeTrial: '$offerIsFreeTrial',
        partnerId: { $toObjectId: '$partnerId' },
        payloads: 1,
        pickupGeo: '$pickupGeo',
        referringSource: '$referringSource',
        rewardCash: '$rewardCash',
        rewardPoints: '$rewardPoints',
        session: '$session',
        status: enforceStatus('$status'),
        transactionAmount: '$transactionAmount',
        transactionId: '$transactionId',
        tripId: '$tripId',
        tripMatchedDate: '$tripMatchedDate',
        tripPlatform: '$tripPlatform',
        tripState: '$tripState',
        type: '$type',
        updatedAt,
        userId: '$userId',
        voucherId: '$voucherId',
        voucherRedemptionId: '$voucherRedemptionId',
      },
    },
    {
      $merge: {
        into: 'offerclaims',
        on: ['_id'],
        whenMatched: 'replace',
        whenNotMatched: 'insert',
      },
    },
  ]
}
