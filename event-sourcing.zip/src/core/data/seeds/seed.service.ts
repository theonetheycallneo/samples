import { Injectable } from '@nestjs/common'
// tslint:disable-next-line no-implicit-dependencies
import { Polygon } from 'geojson'
import { Alaska } from '../models/fixtures/alaska.territory'
import { ContiguousUnitedStates } from '../models/fixtures/contiguous.territory'
import { Guam } from '../models/fixtures/guam.territory'
import { Hawaii } from '../models/fixtures/hawaii.territory'
import { PuertoRico } from '../models/fixtures/puerto-rico.territory'
import { VirginIslands } from '../models/fixtures/virgin-islands.territory'
import { RepositoryProvider } from '../repositories'

@Injectable()
export class SeedService {
  constructor(private readonly repositories: RepositoryProvider) {}

  public async seedAll() {
    const fixtures: Array<{
      name: string
      polygon: {
        coordinates: Polygon['coordinates']
        type: string | 'Polygon' | any
      }
    }> = [Alaska, ContiguousUnitedStates, Guam, Hawaii, PuertoRico, VirginIslands]
    await Promise.all(
      fixtures.map(fixture => {
        if (fixture.name) {
          return this.repositories.territories.findOneAndUpdateByName(fixture.name, fixture)
        }
      }),
    )
  }
}
