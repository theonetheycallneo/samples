import { Module } from '@nestjs/common'
import { DataModule } from '../data.module'
import { SeedService } from './seed.service'

const providers = [SeedService]

@Module({
  imports: [DataModule],
  exports: providers,
  controllers: [],
  providers,
})
export class SeedModule {}
