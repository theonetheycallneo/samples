import { Module } from '@nestjs/common'
import { SSMModule } from '@freebird/nest-ssm'
import { MongoConfigService } from './mongo-config.service'

@Module({
  imports: [SSMModule],
  providers: [MongoConfigService],
  exports: [MongoConfigService],
})
export class MongoConfigModule {}
