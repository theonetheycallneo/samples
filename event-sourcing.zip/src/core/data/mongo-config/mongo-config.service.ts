import { URL } from 'url'
import { Injectable } from '@nestjs/common'
import { SSMService } from '@freebird/nest-ssm'
import { defaultMongoConnectionOptions } from '@freebird/typegoose-utils'
import { TypegooseModuleOptions } from 'nestjs-typegoose'
import { ConnectionOptions } from 'mongoose'

interface IMongoSecret {
  NAME: string
  PASS: string
  SRV: string
  URI: string
  USER: string
}

@Injectable()
export class MongoConfigService {
  constructor(private readonly ssm: SSMService) {}

  public async getConfig(): Promise<TypegooseModuleOptions> {
    const secret = await this.ssm.getSecret<IMongoSecret>(process.env.MONGO_SECRET!)
    const uri = new URL(secret.SRV)
    const uriString = `${uri.protocol}//${secret.USER}:${secret.PASS}@${uri.host}`
    const options: TypegooseModuleOptions & ConnectionOptions = {
      ...defaultMongoConnectionOptions,
      uri: uriString,
      dbName: secret.NAME,
    }
    return options
  }
}
