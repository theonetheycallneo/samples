import { Injectable } from '@nestjs/common'
import { OfferClaimEventsRepository } from './offer-claim-events.repository'
import { OfferClaimsRepository } from './offer-claims.repository'
import { TerritoriesRepository } from './territories.repository'
import { UserStatsRepository } from './user-stats.repository'

export * from './offer-claim-events.repository'
export * from './offer-claims.repository'
export * from './territories.repository'
export * from './user-stats.repository'

export const Repositories = [
  OfferClaimEventsRepository,
  OfferClaimsRepository,
  TerritoriesRepository,
  UserStatsRepository,
]

@Injectable()
export class RepositoryProvider {
  constructor(
    public readonly offerClaims: OfferClaimsRepository,
    public readonly offerClaimEvents: OfferClaimEventsRepository,
    public readonly territories: TerritoriesRepository,
    public readonly users: UserStatsRepository,
  ) {}
}
