import { OfferClaimEventTypes, ClaimTypes } from '@freebird/contracts-offer-claims'
import { TripStates } from '@freebird/contracts-trips'
import { Injectable } from '@nestjs/common'
import { InjectModel } from 'nestjs-typegoose'
import { Types } from 'mongoose'
import { getUserSnapshotPipeline } from '../aggregates/user-snapshot.pipeline'
import {
  OfferClaim,
  OfferClaimModel,
  OfferClaimSortableFields,
  OfferClaimFilterableFields,
  OfferClaimDocument,
} from '../models'
import { IContext } from '../../interfaces/context.interface'

type ObjectId = Types.ObjectId

interface IOfferClaimsCountDocumentsByIdAndStatus {
  _id: ObjectId
  status: {
    $in: OfferClaimEventTypes[]
  }
  tripState: {
    $nin: TripStates[]
  }
}

interface IOfferClaimsCountDocumentsByOfferId {
  offerId?: ObjectId
  userId: ObjectId
}

interface IOfferClaimsCandidateRequirements {
  createdAt: {
    $gte: Date
    $lte: Date
  }
  userId: ObjectId
}

type IOfferClaimsCountDocumentsConditions =
  | IOfferClaimsCandidateRequirements
  | IOfferClaimsCountDocumentsByIdAndStatus
  | IOfferClaimsCountDocumentsByOfferId

export const MatchingMeters = 200
export const MatchingMetersAnywhere = 8046.72

const logTarget = 'claims:repository:offers: '

export interface IOfferClaimsSortTuple {
  id: OfferClaimSortableFields
  desc: boolean
}

export type TOfferClaimsHistoryFilterableValue =
  | string
  | number
  | OfferClaimEventTypes
  | Date
  | Types.ObjectId

export interface IOfferClaimsHistoryFilterTuple {
  id: OfferClaimFilterableFields
  value: TOfferClaimsHistoryFilterableValue
}

interface IOfferClaimsHistoryPaginationParams {
  userId: Types.ObjectId
  page?: number
  pageSize?: number
  sortBy?: IOfferClaimsSortTuple[]
  filterBy?: IOfferClaimsHistoryFilterTuple[]
}

@Injectable()
export class OfferClaimsRepository {
  constructor(@InjectModel(OfferClaim) private readonly model: OfferClaimModel) {}

  public async countDocuments(countConditions: IOfferClaimsCountDocumentsConditions) {
    return await this.model.countDocuments(countConditions).exec()
  }

  public async countIssuedClaims(_context: IContext, params: IOfferClaimsCandidateRequirements) {
    const { createdAt, userId } = params
    return await this.model
      .countDocuments({
        userId,
        status: {
          $in: [
            OfferClaimEventTypes.expired,
            OfferClaimEventTypes.fulfilled,
            OfferClaimEventTypes.tripMatched,
          ],
        },
        createdAt,
        tripState: {
          $nin: [
            TripStates.driver_canceled,
            TripStates.rider_canceled,
            TripStates.no_drivers_available,
            TripStates.failed,
            TripStates.unknown,
          ],
        },
      })
      .exec()
  }

  public async findIssuedClaimOnTrip(
    _context: IContext,
    params: { claimId: ObjectId; offerId: ObjectId },
  ) {
    const { claimId, offerId } = params
    return await this.model
      .findOne({
        _id: claimId,
        offerId,
        status: {
          $in: [OfferClaimEventTypes.tripMatched],
        },
        tripState: {
          $nin: [
            TripStates.completed,
            TripStates.driver_canceled,
            TripStates.rider_canceled,
            TripStates.no_drivers_available,
            TripStates.failed,
            TripStates.unknown,
          ],
        },
      })
      .exec()
  }

  public async findIssuableClaim(_context: IContext, params: { claimId: ObjectId }) {
    const { claimId } = params
    return await this.model
      .findOne({
        _id: claimId,
        $or: [
          {
            status: {
              $in: [OfferClaimEventTypes.expired, OfferClaimEventTypes.fulfilled],
            },
          },
          {
            status: OfferClaimEventTypes.tripMatched,
            tripState: {
              $nin: [
                TripStates.driver_canceled,
                TripStates.rider_canceled,
                TripStates.no_drivers_available,
                TripStates.failed,
                TripStates.unknown,
              ],
            },
          },
        ],
      })
      .exec()
  }

  public async findExpirableClaims(context: IContext, params: { expiresAt: Date }) {
    const target = `${logTarget}findExpirableClaims`
    const { logger } = context
    const conditions = {
      expiresAt: {
        $lte: params.expiresAt.toISOString(),
      },
      $or: [
        {
          status: {
            $nin: [
              OfferClaimEventTypes.tripMatched,
              OfferClaimEventTypes.fulfilled,
              OfferClaimEventTypes.expired,
              OfferClaimEventTypes.unexpired,
            ],
          },
          tripState: {
            $nin: [
              TripStates.canceled,
              TripStates.no_drivers_available,
              TripStates.rider_canceled,
              TripStates.failed,
              TripStates.unknown,
            ],
          },
        },
        {
          status: OfferClaimEventTypes.tripMatched,
          tripState: {
            $in: [
              TripStates.canceled,
              TripStates.no_drivers_available,
              TripStates.rider_canceled,
              TripStates.failed,
              TripStates.unknown,
            ],
          },
        },
      ],
    }
    logger.debug(`${target} query conditions`, {
      conditions,
      readyState: this.model.collection.conn.readyState,
    })
    try {
      const results = await this.model
        .find(conditions)
        .select('-payloads')
        .limit(20)
        .read('primary')
        .exec()
      logger.debug(`${target} query results`, {
        conditions,
        readyState: this.model.collection.conn.readyState,
        results,
      })

      return results
    } catch (error) {
      const { message } = error
      logger.error(`${target} ${message}`, {
        conditions,
        error,
        readyState: this.model.collection.conn.readyState,
      })
      throw error
    }
  }

  public async findOneById(id: ObjectId) {
    return await this.model
      .findOne({ _id: id })
      .select('-payloads')
      .read('primary')
      .exec()
  }

  public async findOneCompletedTripMatchedById(params: { claimId: ObjectId }) {
    return await this.model
      .findOne({
        _id: params.claimId,
        status: { $eq: OfferClaimEventTypes.tripMatched },
        tripState: TripStates.droppedoff,
      })
      .exec()
  }

  public async findByUserId(userId: ObjectId) {
    const offerClaims = await this.model
      .find({ userId })
      .select('-payloads')
      .sort({ createdAt: -1 })
      .limit(25)
      .exec()
    return offerClaims
  }

  public async findOneByTripAndUserId(
    context: IContext,
    params: {
      tripId: ObjectId
      userId: ObjectId
    },
  ) {
    const target = `${logTarget}findOneByTripAndUserId`
    const { tripId, userId } = params
    const conditions = {
      tripId,
      userId,
      status: {
        $in: [
          OfferClaimEventTypes.issued,
          OfferClaimEventTypes.inspected,
          OfferClaimEventTypes.tripMatched,
          OfferClaimEventTypes.unexpired,
        ],
      },
    }
    context.logger.debug(`${target} query conditions`, {
      conditions: JSON.stringify(conditions),
    })
    const offerClaim = await this.model
      .findOne(conditions)
      .read('primary')
      .exec()
    return offerClaim
  }

  public async findOneByDestinationGeo(
    context: IContext,
    params: {
      geo: [number, number]
      maxDistance?: number
      type?: { $in: ClaimTypes[] }
      userId: ObjectId
    },
  ) {
    const target = `${logTarget}findByDestinationGeo`
    const { geo, maxDistance, type, userId } = params
    const [lng, lat] = geo
    const conditions = {
      destinationGeo: {
        $near: {
          $minDistance: 0,
          $maxDistance: maxDistance ?? MatchingMeters,
          $geometry: { type: 'Point', coordinates: [lng, lat] },
        },
      },
      userId,
      status: {
        $in: [
          OfferClaimEventTypes.issued,
          OfferClaimEventTypes.inspected,
          OfferClaimEventTypes.tripMatched,
          OfferClaimEventTypes.unexpired,
        ],
      },
      tripState: {
        $nin: [
          TripStates.droppedoff,
          TripStates.driver_canceled,
          TripStates.rider_canceled,
          TripStates.no_drivers_available,
          TripStates.failed,
          TripStates.unknown,
        ],
      },
      ...(type ? { type } : null),
    }
    context.logger.debug(`${target} query conditions`, {
      conditions: JSON.stringify(conditions),
    })
    const offerClaim = await this.model
      .findOne(conditions)
      .read('primary')
      .sort({ createdAt: -1 })
      .exec()
    return offerClaim
  }

  public async upsertUserSnapshot(context: IContext, userId: ObjectId) {
    const target = `${logTarget}upsertUserSnapshot`
    const { logger } = context
    const pipeline = getUserSnapshotPipeline({ userId })
    logger.debug(`${target} pipeline`, {
      userId,
      pipeline: JSON.stringify(pipeline),
    })
    await this.model.aggregate(pipeline).exec()
  }

  public async getPaginatedHistoryByUserId(
    params: IOfferClaimsHistoryPaginationParams,
    _ctx: IContext,
  ) {
    const conditions = { userId: params.userId }

    if (params.filterBy) {
      params.filterBy.forEach(condition => {
        if (Types.ObjectId.isValid(condition.value as any)) {
          conditions[condition.id] = Types.ObjectId(condition.value as any)
        } else if (condition.id === 'createdAt') {
          conditions[condition.id] = { $eq: condition.value }
        } else if (typeof condition.value === 'string') {
          conditions[condition.id] = new RegExp(condition.value, 'ig')
        } else {
          conditions[condition.id] = condition.value
        }
      })
    }

    const totalItems = await this.model.countDocuments(conditions).exec()
    const pageSize = params.pageSize ?? 10
    const totalPages = Math.ceil(totalItems / pageSize)
    const sortBy = params.sortBy ?? null
    let page = params.page || 1

    if (totalPages === 0 || page <= 0) {
      page = 1
    } else if (page > totalPages) {
      page = totalPages
    }

    const offset = pageSize * (page - 1)

    const sort = sortBy
      ? sortBy.reduce((obj, tuple: IOfferClaimsSortTuple) => {
          obj[tuple.id] = tuple.desc === true ? -1 : 1
          return obj
        }, {})
      : {}

    const returnFields = {
      createdAt: 1,
      expiresAt: 1,
      destinationGeo: 1,
      destinationAddress: 1,
      destinationName: 1,
      locationGeo: 1,
      locationId: 1,
      offerId: 1,
      rewardCash: 1,
      rewardPoints: 1,
      status: 1,
      transactionId: 1,
      tripId: 1,
      updatedAt: 1,
      userId: 1,
    }

    let results: OfferClaimDocument[] = []

    if (totalItems > 0) {
      let query = this.model
        .find(conditions, returnFields)
        .limit(pageSize)
        .skip(offset)
        .toConstructor<OfferClaimDocument[]>()

      query = sortBy
        ? sortBy.reduce((q, tuple: IOfferClaimsSortTuple) => {
            return new q().sort({ [tuple.id]: tuple.desc === true ? -1 : 1 }).toConstructor()
          }, query)
        : query

      results = await new query().exec()
    }

    return {
      page,
      pageSize,
      totalItems,
      totalPages,
      skipped: offset,
      sort,
      results,
    }
  }
}
