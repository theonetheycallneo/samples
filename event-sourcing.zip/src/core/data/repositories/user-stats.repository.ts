import { Injectable } from '@nestjs/common'
import { Types } from 'mongoose'
import { InjectModel } from 'nestjs-typegoose'
import { UserStats, UserStatsModel } from '../models'

type ObjectId = Types.ObjectId

export interface IUserSnapshotAggregateParameters {
  userId: ObjectId
}

@Injectable()
export class UserStatsRepository {
  constructor(@InjectModel(UserStats) private readonly model: UserStatsModel) {}

  public async findOneById(id: ObjectId) {
    return await this.model.findOne({ _id: id }).exec()
  }
  public async findOneAndUpdate(id: ObjectId, update: any) {
    return await this.model.findOneAndUpdate({ _id: id }, update, { upsert: true })
  }
}
