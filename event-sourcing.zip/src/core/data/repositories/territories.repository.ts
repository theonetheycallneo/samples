import { Injectable } from '@nestjs/common'
import { Types } from 'mongoose'
import { InjectModel } from 'nestjs-typegoose'
import { DeepPartial } from 'utility-types'
import { Territory, TerritoryModel } from '../models'

interface ITerritoryCountDocuments {
  coordinates: [number, number]
}

type ObjectId = Types.ObjectId

@Injectable()
export class TerritoriesRepository {
  constructor(@InjectModel(Territory) private readonly model: TerritoryModel) {}

  public async countDocuments(conditions: ITerritoryCountDocuments) {
    const { coordinates } = conditions
    return await this.model
      .countDocuments({
        polygon: {
          $geoIntersects: {
            $geometry: {
              coordinates,
              type: 'Point',
            },
          },
        },
      })
      .exec()
  }

  public async findOneById(id: ObjectId) {
    return await this.model.findOne({ _id: id }).exec()
  }

  public async findOneAndUpdateByName(name: string, updateConditions: DeepPartial<Territory>) {
    return await this.model
      .findOneAndUpdate({ name }, { $set: updateConditions }, { new: true, upsert: true })
      .exec()
  }
}
