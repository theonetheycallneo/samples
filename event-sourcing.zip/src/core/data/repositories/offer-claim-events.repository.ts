import {
  IMatchedTransactionForRedemptionPayload,
  OfferClaimEventTypes,
} from '@freebird/contracts-offer-claims'
import { ITripUpdatedPayload } from '@freebird/contracts-trips'
import { Injectable } from '@nestjs/common'
import { Types } from 'mongoose'
import { InjectModel } from 'nestjs-typegoose'
import { getOfferClaimSnapshotPipeline } from '../aggregates/offer-claim-snapshot.pipeline'
import { getUserSnapshotPipeline } from '../aggregates/user-snapshot.pipeline'
import { OfferClaimEventModel, OfferClaimEvent } from '../models'
import { IContext } from '../../interfaces/context.interface'
import { OfferClaimPostPayloadDTO } from '../../../http/dtos/offer-claims.dto'

type ObjectId = Types.ObjectId

export interface IOfferClaimIssuedEventParameters {
  payload: OfferClaimPostPayloadDTO
  offerId: ObjectId
  userId: ObjectId
}

export interface IOfferClaimInspectedEventParameters {
  claimId: ObjectId
  payload: {
    inTerritory: boolean
  }
  userId: ObjectId
}

export interface IOfferClaimTripMatchedEventParameters {
  claimId: ObjectId
  payload: ITripUpdatedPayload
}

export interface IOfferClaimFulfillWithTransaction {
  claimId: ObjectId
  transactionId: ObjectId
  payload: IMatchedTransactionForRedemptionPayload
}

export interface IOfferClaimFulfillWithTrip {
  claimId: ObjectId
}

export type IOfferClaimFulfilledEventParameters =
  | IOfferClaimFulfillWithTrip
  | IOfferClaimFulfillWithTransaction

export interface IOfferClaimExpiredEventParameters {
  claimId: ObjectId
}

export interface IOfferClaimSnapshotAggregateParameters {
  claimId: ObjectId
}

type IOfferClaimEventParameters =
  | IOfferClaimInspectedEventParameters
  | IOfferClaimIssuedEventParameters
  | IOfferClaimTripMatchedEventParameters
  | IOfferClaimFulfilledEventParameters

const logTarget = 'claims:repository:events: '

@Injectable()
export class OfferClaimEventsRepository {
  constructor(@InjectModel(OfferClaimEvent) public readonly model: OfferClaimEventModel) {}

  public async createEvent(
    context: IContext,
    data: IOfferClaimEventParameters,
    eventType: OfferClaimEventTypes,
  ) {
    const target = `${logTarget}createEvent`
    const { logger } = context
    logger.debug(`${target} save model`, { eventType, data })
    const offerClaimEvent = new this.model({ ...data, _id: null, eventType })
    await offerClaimEvent.save()

    return offerClaimEvent
  }

  public async upsertSnapshot(context: IContext, claimId: ObjectId) {
    const target = `${logTarget}upsertSnapshot`
    const { logger } = context
    const pipeline = getOfferClaimSnapshotPipeline({ claimId })
    logger.debug(`${target} pipeline`, {
      claimId,
      pipeline: JSON.stringify(pipeline),
    })
    await this.model.aggregate(pipeline).exec()
  }

  public async upsertUserSnapshot(context: IContext, userId: ObjectId) {
    const target = `${logTarget}upsertUserSnapshot`
    const { logger } = context
    const pipeline = getUserSnapshotPipeline({ userId })
    logger.debug(`${target} pipeline`, {
      userId,
      pipeline: JSON.stringify(pipeline),
    })
    await this.model.aggregate(pipeline).exec()
  }
}
