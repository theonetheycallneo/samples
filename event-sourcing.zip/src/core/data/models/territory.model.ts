import { index, prop, modelOptions, DocumentType } from '@typegoose/typegoose'
// tslint:disable-next-line no-implicit-dependencies
import { Polygon } from 'geojson'
import { Model, Types } from 'mongoose'

const schemaOptions = { read: 'secondaryPreferred', timestamps: true }

@index({ name: 1 }, { unique: true })
@index({ polygons: '2dsphere' })
@modelOptions({ schemaOptions })
export class Territory {
  @prop()
  public _id: Types.ObjectId

  @prop({ required: true })
  public name: string

  @prop()
  public polygon: Polygon
}

export type TerritoryDocument = DocumentType<Territory>
export type TerritoryModel = Model<TerritoryDocument>
