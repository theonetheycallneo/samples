import { ClaimTypes, OfferClaimEventTypes } from '@freebird/contracts-offer-claims'
import { TripPlatform, TripStates } from '@freebird/contracts-trips'
import { index, prop, modelOptions, DocumentType } from '@typegoose/typegoose'
import { Model, Types } from 'mongoose'

export const Expiration = {
  inHours: 2,
  inSeconds: 7200,
  inMilliseconds: 7200000,
}

const schemaOptions = { read: 'secondaryPreferred', timestamps: true }

// query indexes
@index({ expiresAt: 1, status: 1, tripState: 1 }, { sparse: true })
@index(
  { destinationGeo: '2dsphere', userId: 1, status: 1, tripState: 1, type: 1 },
  { sparse: true },
)
@index({ offerId: 1, status: 1, tripState: 1 }, { sparse: true })
@index({ status: 1, tripState: 1 }, { sparse: true })
@index({ tripId: 1, userId: 1, status: 1 }, { sparse: true })
@index({ userId: 1, offerId: 1 }, { sparse: true })
@index({ userId: 1, status: 1, createdAt: 1, tripState: 1 }, { sparse: true })
// index with destinationGeo array
@index({
  userId: 1,
  tripId: 1,
  transactionId: 1,
  offerId: 1,
  status: 1,
  expiresAt: 1,
  destinationGeo: 1,
  destinationAddress: 1,
  destinationName: 1,
  locationId: 1,
  rewardCash: 1,
  rewardPoints: 1,
  createdAt: 1,
  updatedAt: 1,
})
// index with locationGeo array
@index({
  userId: 1,
  tripId: 1,
  transactionId: 1,
  offerId: 1,
  status: 1,
  expiresAt: 1,
  destinationAddress: 1,
  destinationName: 1,
  locationGeo: 1,
  locationId: 1,
  rewardCash: 1,
  rewardPoints: 1,
  createdAt: 1,
  updatedAt: 1,
})
// sort indexes
@index({ createdAt: 1 })
@index({ updatedAt: 1 })
@modelOptions({ schemaOptions })
export class OfferClaim {
  @prop()
  public _id: Types.ObjectId

  @prop()
  public campaign: any | null

  @prop({ default: new Date() })
  public createdAt: Date

  @prop({ default: '' })
  public destinationAddress: string

  @prop()
  public destinationGeo: [number, number]

  @prop({ default: '' })
  public destinationName: string

  @prop({ default: new Date() })
  public expiresAt: Date

  @prop()
  public inTerritory: boolean

  @prop()
  public isReceiptReceived: boolean

  @prop()
  public isRedeemImmediately: boolean

  @prop()
  public isSandbox: boolean

  @prop()
  public googlePlaceId: string

  @prop()
  public googlePlace: object

  @prop({ default: null })
  public locationId: Types.ObjectId | null

  @prop()
  public locationGeo: [number, number]

  @prop({ default: null })
  public locationGroupId: Types.ObjectId | null

  @prop()
  public locationServiceFee: number

  @prop()
  public offerId: Types.ObjectId

  @prop()
  public offerBudget: number

  @prop()
  public offerIsFreeTrial: boolean

  @prop({ default: null })
  public partnerId: Types.ObjectId | null

  @prop()
  public pickupGeo: [number, number]

  @prop({ default: 0 })
  public rewardCash: number

  @prop({ default: 0 })
  public rewardPoints: number

  @prop({
    default: OfferClaimEventTypes.requested,
    enum: OfferClaimEventTypes,
    index: true,
  })
  public status: OfferClaimEventTypes

  @prop({ default: 0 })
  public transactionAmount: number

  @prop()
  public transactionId: Types.ObjectId

  @prop({ default: null })
  public tripId: Types.ObjectId | null

  @prop({ enum: TripStates, default: null })
  public tripState?: TripStates

  @prop({ enum: TripPlatform })
  public tripPlatform: TripPlatform

  @prop({ default: new Date() })
  public tripMatchedDate: Date

  @prop({ enum: ClaimTypes })
  public type: ClaimTypes

  @prop({ default: new Date() })
  public updatedAt: Date

  @prop()
  public userId: Types.ObjectId

  @prop()
  public voucherId: Types.ObjectId

  @prop()
  public voucherRedemptionId: Types.ObjectId | null
}

export type OfferClaimDocument = DocumentType<OfferClaim>
export type OfferClaimModel = Model<OfferClaimDocument>

type ExtractStrict<T, U extends T> = Extract<T, U>

export type OfferClaimSortableFields = ExtractStrict<
  keyof OfferClaimDocument,
  'createdAt' | 'updatedAt'
>

export type OfferClaimFilterableFields = ExtractStrict<
  keyof OfferClaimDocument,
  | '_id'
  | 'createdAt'
  | 'destinationAddress'
  | 'destinationName'
  | 'locationId'
  | 'offerId'
  | 'rewardCash'
  | 'rewardPoints'
  | 'status'
  | 'transactionId'
  | 'tripId'
  | 'userId'
>

function createEnumObject<T extends string>(o: { [P in T]: P }) {
  return o
}

export const OfferClaimSortablFieldsEnumObj = createEnumObject<OfferClaimSortableFields>({
  createdAt: 'createdAt',
  updatedAt: 'updatedAt',
})

export const OfferClaimFilterableFieldsEnumObj = createEnumObject<OfferClaimFilterableFields>({
  _id: '_id',
  createdAt: 'createdAt',
  destinationAddress: 'destinationAddress',
  destinationName: 'destinationName',
  locationId: 'locationId',
  offerId: 'offerId',
  rewardCash: 'rewardCash',
  rewardPoints: 'rewardPoints',
  status: 'status',
  transactionId: 'transactionId',
  tripId: 'tripId',
  userId: 'userId',
})
