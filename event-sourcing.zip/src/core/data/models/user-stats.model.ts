import { prop, modelOptions, DocumentType } from '@typegoose/typegoose'
import { Model, Types } from 'mongoose'

const schemaOptions = { read: 'secondaryPreferred', timestamps: true }

@modelOptions({ schemaOptions })
export class UserStats {
  @prop()
  public _id: Types.ObjectId

  @prop({ default: 0 })
  public fulfilledCount: number

  @prop({ default: 0 })
  public fulfilledInTerritoryCount: number

  @prop({ default: 0 })
  public legacyRideCount: number
}

export type UserStatsDocument = DocumentType<UserStats>
export type UserStatsModel = Model<UserStatsDocument>
