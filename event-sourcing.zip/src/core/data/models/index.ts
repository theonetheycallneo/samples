import { setGlobalOptions } from '@typegoose/typegoose'
setGlobalOptions({ globalOptions: { useNewEnum: true } })

export * from './offer-claim-event.model'
export * from './offer-claim.model'
export * from './territory.model'
export * from './user-stats.model'
