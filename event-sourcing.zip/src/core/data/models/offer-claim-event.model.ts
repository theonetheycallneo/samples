import {
  IMatchedTransactionForRedemptionPayload,
  OfferClaimEventTypes,
} from '@freebird/contracts-offer-claims'
import { ITripUpdatedPayload } from '@freebird/contracts-trips'
import { index, prop, modelOptions, DocumentType } from '@typegoose/typegoose'
import { IsEnum, IsMongoId, IsObject } from 'class-validator'
import { Model, Types } from 'mongoose'

type ObjectId = Types.ObjectId

const schemaOptions = { read: 'secondaryPreferred', strict: false, timestamps: true }

@index({ claimId: 1 })
@index({ createdAt: 1 })
@modelOptions({ schemaOptions })
export class OfferClaimEvent {
  @IsEnum(OfferClaimEventTypes)
  @prop({ enum: OfferClaimEventTypes })
  public eventType: OfferClaimEventTypes

  @IsObject()
  @prop()
  public payload: any

  @IsMongoId()
  @prop()
  public offerId: ObjectId

  @IsMongoId()
  @prop()
  public userId: ObjectId
}

export class TripEvent extends OfferClaimEvent {
  @IsMongoId()
  @prop()
  public claimId: ObjectId

  @IsMongoId()
  @prop()
  public tripId: ObjectId

  @prop() // this will create a virtual property called 'fullName'
  get payloadAsTrip() {
    return this.payload as ITripUpdatedPayload
  }
}

export class TransactionEvent extends TripEvent {
  @IsMongoId()
  @prop()
  public transactionId: ObjectId

  @prop() // this will create a virtual property called 'fullName'
  get payloadAsTransaction() {
    return this.payload as IMatchedTransactionForRedemptionPayload
  }
}

export type OfferClaimEventDocument = DocumentType<OfferClaimEvent>
export type OfferClaimEventModel = Model<OfferClaimEventDocument>
