import Mongoose from 'mongoose'
import { lyftEstimates } from './lyft-estimates'
import { uberEstimates } from './uber-estimates'

const ObjectId = Mongoose.Types.ObjectId

export const OfferClaimFixture = {
  _id: ObjectId('5d5c8c0f238a07818a32540c'),
  campaign: null,
  campaignCreative: null,
  createdAt: new Date('2019-08-21T00:10:58.366Z'),
  isSandbox: false,
  destination: ObjectId('598472d6710880a8e787b07e'),
  location: ObjectId('598472d6710880a8e787b07e'),
  meta: {
    estimates: {
      lyft: lyftEstimates,
      uber: uberEstimates,
    },
    referringSource: {
      id: '598472d6710880a8e787b07e',
      feature: 'Search Recent Rides',
      name: 'GooglePlaceId',
    },
  },
  offerId: ObjectId('598472d7710880a8e787b103'),
  offerRideContribution: 4,
  points: 0,
  updatedAt: new Date('2019-08-23T12:42:23.349Z'),
  userId: ObjectId('5c967eef961206be6d47e8be'),
  voucherId: null,
  organizationId: null,
  uberRedemption: null,
}
