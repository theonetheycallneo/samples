import { IContextLogger } from '@freebird/logger'

export interface IContext {
  logger: IContextLogger
}
