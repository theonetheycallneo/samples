import { Injectable } from '@nestjs/common'
import { OfferClaimEventTypes } from '@freebird/contracts-offer-claims'
import { IContext } from '../interfaces/context.interface'
import { OfferClaimDocument } from '../data/models'
import { RepositoryProvider } from '../data/repositories'

const logTarget = 'claims:inspected: '

@Injectable()
export class OfferClaimInspectedEvent {
  constructor(private readonly repositories: RepositoryProvider) {}

  public async handle(context: IContext, claim: OfferClaimDocument) {
    const target = `${logTarget}handle`
    const { logger } = context
    const type = OfferClaimEventTypes.inspected
    const { _id: claimId, destinationGeo, userId } = claim
    // check if trip was taken in a marketable territory
    const countTerritories = await this.repositories.territories.countDocuments({
      coordinates: destinationGeo,
    })
    // store incoming matched trip
    const inTerritory = countTerritories > 0
    logger.debug(`${target} check inTerritory`, {
      countTerritories,
      inTerritory,
      claim,
    })
    logger.mergeContext({
      'x-claims-claim-id': claimId.toString(),
      'x-user-id': userId.toString(),
    })
    const eventPayload = {
      claimId,
      payload: { inTerritory },
      userId,
    }
    const event = await this.repositories.offerClaimEvents.createEvent(context, eventPayload, type)
    await this.repositories.offerClaimEvents.upsertSnapshot(context, claimId)
    logger.debug(`${target} updated claim snapshot`, { claimId })
    const offerClaim = await this.repositories.offerClaims.findOneById(claimId)
    if (offerClaim) {
      logger.debug(`${target} event successful`, { offerClaim })
      // @TODO: Currently no other downstream service requires this event,
      //   but this is the place to emit it when the time comes:
      // await this.putToTopic(context, this.transformModelToPayload(context, offerClaim))
    } else {
      logger.error(`${target} unable to inspect claim not found`, { claimId })
    }
    return { event, inTerritory, offerClaim }
  }
}
