import { Analytics } from '@freebird/analytics-transport'
import { OfferClaimEventTypes } from '@freebird/contracts-offer-claims'
import { Injectable, NotFoundException } from '@nestjs/common'
import { IContext } from '../interfaces/context.interface'
import { RepositoryProvider, IOfferClaimExpiredEventParameters } from '../data/repositories'

const logTarget = 'claims:unexpired: '

@Injectable()
export class OfferClaimUnexpiredEvent {
  constructor(private readonly repositories: RepositoryProvider) {}

  public async handle(context: IContext, payload: IOfferClaimExpiredEventParameters) {
    const target = `${logTarget}handle`
    const { logger } = context
    const { claimId } = payload
    logger.debug(`${target} findOneById`, { claimId })
    const claim = await this.repositories.offerClaims.findOneById(claimId)
    if (claim) {
      const type = OfferClaimEventTypes.unexpired
      logger.debug(`${target} createEvent`, { claimId, type })
      const event = await this.repositories.offerClaimEvents.createEvent(context, payload, type)
      await this.repositories.offerClaimEvents.upsertSnapshot(context, claimId)
      const offerClaim = await this.repositories.offerClaims.findOneById(claimId)
      logger.debug(`${target} updated snapshot`, { claimId, offerClaim })
      if (offerClaim) {
        try {
          const analyticsPayload = {
            event: 'CLAIM_UNEXPIRED',
            properties: {
              destinationName: claim.destinationName,
              rewardCash: claim.rewardCash,
              rewardPoints: claim.rewardPoints,
            },
            type: 'CLAIM_UNEXPIRED',
            userId: claim.userId.toString(),
          }
          const analytics = new Analytics(process.env.ANALYTICS_BUS_STREAM_NAME!, logger)
          await analytics.track(`Offer Claim Unexpired`, analyticsPayload)
        } catch (error) {
          const { message } = error
          logger.warn(`${target} ${message}`, { offerClaim })
        }
        logger.debug(`${target} event successful`, { offerClaim })
      } else {
        logger.error(`${target} unable to expire claim not found`, { claimId })
      }
      return { event, offerClaim }
    }
    throw new NotFoundException('OfferClaim not found')
  }
}
