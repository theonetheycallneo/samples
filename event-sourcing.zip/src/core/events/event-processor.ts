import {
  IMatchedTransactionForRedemptionPayload,
  ClaimTypes,
} from '@freebird/contracts-offer-claims'
import { ITripUpdatedPayload } from '@freebird/contracts-trips'
import { Injectable } from '@nestjs/common'
import { Types } from 'mongoose'
import { IOfferClaimIssuedEventParameters, RepositoryProvider } from '../data/repositories'
import { IContext } from '../interfaces/context.interface'
import { EventHandlerProvider } from '../events'

type ObjectId = Types.ObjectId

const logTarget = 'claims:event-processor: '

@Injectable()
export class EventProcessor {
  constructor(
    private readonly events: EventHandlerProvider,
    private readonly repositories: RepositoryProvider,
  ) {}

  public async requestClaim(context: IContext, payload: IOfferClaimIssuedEventParameters) {
    const target = `${logTarget}requestClaim`
    const { logger } = context
    logger.debug(`${target} incoming payload`, {
      payload: JSON.stringify(payload),
    })
    const { offerClaim: newClaim } = await this.events.issued.handle(context, payload)
    logger.debug(`${target} new claim issued`, { newClaim: JSON.stringify(newClaim) })
    if (newClaim) {
      const { inTerritory, offerClaim } = await this.events.inspected.handle(context, newClaim)
      if (offerClaim) {
        await this.events.issued.putToTopic(
          context,
          this.events.issued.transformModelToPayload(context, offerClaim),
        )
        logger.debug(`${target} claim issued, inspected, and sent succesfully`, {
          inTerritory,
          offerClaim,
        })
        return offerClaim
      }
    }
    return newClaim
  }

  public async matchClaim(context: IContext, payload: ITripUpdatedPayload) {
    const target = `${logTarget}matchClaim`
    const { logger } = context
    logger.debug(`${target} incoming payload`, { payload })
    const result = await this.events.tripMatched.handle(context, payload)
    // fulfill immediately when trip completes
    if (result?.isDroppedOff && result?.offerClaim) {
      logger.debug(`${target} checking whether or not to fulfill immediately on trip completed`, {
        payload,
        result,
      })
      const {
        offerClaim: { _id: claimId, isRedeemImmediately, type },
      } = result
      switch (type) {
        case ClaimTypes.brandedAnywhere:
        case ClaimTypes.brandedHome:
        case ClaimTypes.brandedWork:
        case ClaimTypes.anywhere:
        case ClaimTypes.home:
        case ClaimTypes.work:
          logger.debug(`${target} attempting to fulfill immediately when trip completes`, {
            payload,
            result,
          })
          await this.events.fulfilled.handle(context, { claimId })
          logger.debug(`${target} claim fulfilled immediately`, {
            payload,
            result,
          })
          break
        default:
          if (isRedeemImmediately) {
            await this.events.fulfilled.handle(context, { claimId })
          }
          return
      }
    }
  }

  public async fulfillClaim(context: IContext, payload: IMatchedTransactionForRedemptionPayload) {
    const target = `${logTarget}fulfillClaim`
    const { logger } = context
    logger.debug(`${target} incoming payload`, { payload })
    const eventPayload = { claimId: payload.claimId, payload, transactionId: payload.transactionId }
    await this.events.fulfilled.handle(context, eventPayload)
  }

  public async expireClaim(context: IContext, payload: { claimId: ObjectId }) {
    const target = `${logTarget}expireClaim`
    const { logger } = context
    logger.debug(`${target} incoming payload`, { payload })
    return await this.events.expired.handle(context, payload)
  }

  public async expireClaims(context: IContext) {
    const target = `${logTarget}expireClaims`
    const { logger } = context
    logger.debug(`${target} invoked`)
    const expirableClaims = await this.repositories.offerClaims.findExpirableClaims(context, {
      expiresAt: new Date(),
    })
    logger.debug(`${target} attempting to expire claims`, { count: expirableClaims.length })
    await Promise.all(
      expirableClaims.map(claim => {
        const claimId = claim._id
        return this.events.expired.handle(context, { claimId })
      }),
    )
  }

  public async unexpireClaim(context: IContext, payload: { claimId: ObjectId }) {
    const target = `${logTarget}expireClaim`
    const { logger } = context
    logger.debug(`${target} incoming payload`, { payload })
    return await this.events.unexpired.handle(context, payload)
  }
}
