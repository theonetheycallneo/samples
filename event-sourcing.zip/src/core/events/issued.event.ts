import { Analytics } from '@freebird/analytics-transport'
import {
  IRedeemVoucherRequestPayload,
  RedeemVoucherRequest,
  RedeemVoucherResponse,
  IRollbackVoucherRequestPayload,
  RollbackVoucherRequest,
  RollbackVoucherResponse,
} from '@freebird/contracts-vouchers'
import { EventTransport, EventDestinations, ISNSEmitParam } from '@freebird/event-transport'
import {
  ClaimTypes,
  OfferClaimIssued,
  IOfferClaimIssuedPayload,
  OfferClaimEventTypes,
} from '@freebird/contracts-offer-claims'
import { invokeLambda } from '@freebird/lambda-rpc'
import { Injectable } from '@nestjs/common'
import Crypto from 'crypto'
import { Types } from 'mongoose'
import { IContext } from '../interfaces/context.interface'
import { OfferClaimDocument, Expiration } from '../data/models'
import { RepositoryProvider, IOfferClaimIssuedEventParameters } from '../data/repositories'

type ObjectId = Types.ObjectId

const logTarget = 'claims:issued: '

@Injectable()
export class OfferClaimIssuedEvent {
  constructor(private readonly repositories: RepositoryProvider) {}

  public async handle(context: IContext, payload: IOfferClaimIssuedEventParameters) {
    const target = `${logTarget}handle`
    const { logger } = context
    const type = OfferClaimEventTypes.issued
    const {
      payload: { destinationAddress, destinationName, offerId, voucherId },
      userId,
    } = payload

    let { claimId, expiresAt } = this.generateClaimIdAndExpiration({
      count: 0,
      userId,
    })

    const issuedClaim = await this.repositories.offerClaims.findIssuedClaimOnTrip(context, {
      claimId,
      offerId,
    })
    if (issuedClaim) {
      return { offerClaim: issuedClaim }
    }

    const candidate = await this.repositories.offerClaims.findIssuableClaim(context, { claimId })
    logger.debug(`${target} claimId generated`, { claimId, offerId, candidate })
    if (candidate) {
      const count = await this.repositories.offerClaims.countIssuedClaims(context, {
        userId,
        createdAt: {
          $gte: candidate.createdAt,
          $lte: candidate.expiresAt,
        },
      })
      logger.debug(`${target} claimId selection was not unique, counting claims by offerId`, {
        claimId,
        offerId,
        count,
      })
      const nextClaim = this.generateClaimIdAndExpiration({
        count: count + 1,
        userId,
      })
      logger.debug(`${target} incrementing claimId to force uniqueness`, {
        claimId,
        expiresAt,
        offerId,
        userId,
        count,
        nextClaim,
      })
      claimId = nextClaim.claimId
      expiresAt = nextClaim.expiresAt
    }
    logger.mergeContext({
      'x-claims-claim-id': claimId.toString(),
      'x-user-id': userId.toString(),
    })

    let voucherRedemptionId: ObjectId | null = null
    const outstandingClaim = await this.repositories.offerClaims.findOneById(claimId)

    // rollback voucher
    if (outstandingClaim && outstandingClaim.voucherRedemptionId) {
      try {
        const voucherRedemptionRollbackParams: IRollbackVoucherRequestPayload = {
          voucherRedemptionId: outstandingClaim.voucherRedemptionId,
        }
        logger.debug(`${target} attempting to rollback voucher...`, voucherRedemptionRollbackParams)
        const redemption = await this.rollbackVoucher(context, voucherRedemptionRollbackParams)
        if (redemption) {
          voucherRedemptionId = (redemption as RollbackVoucherResponse).payload.voucherRedemptionId
          logger.debug(`${target} voucher rollback response`, {
            redemption,
          })
        }
      } catch (error) {
        const { message } = error
        logger.warn(`${target} rollbackVoucher ${message}`, {
          error,
          voucherId,
          userId,
        })
        // throw error
      }
    }

    // redeem voucher
    if (voucherId) {
      try {
        const voucherRedemptionRequestParams: IRedeemVoucherRequestPayload = {
          claimId,
          destinationAddress,
          destinationName,
          voucherId,
          userId,
        }
        logger.debug(`${target} attempting to redeem voucher...`, voucherRedemptionRequestParams)
        const redemption = await this.redeemVoucher(context, voucherRedemptionRequestParams)
        if (redemption) {
          voucherRedemptionId = (redemption as RedeemVoucherResponse).payload.voucherRedemptionId
          logger.debug(`${target} voucher redemption response`, {
            redemption,
            voucherRedemptionRequestParams,
          })
        }
      } catch (error) {
        const { message } = error
        logger.warn(`${target} redeemVoucher ${message}`, {
          error,
          voucherId,
          userId,
        })
        throw error
      }
    }
    const eventPayload = {
      ...payload,
      claimId,
      expiresAt,
      payload: { ...payload.payload, voucherRedemptionId },
    }
    const event = await this.repositories.offerClaimEvents.createEvent(context, eventPayload, type)
    await this.repositories.offerClaimEvents.upsertSnapshot(context, claimId)
    logger.debug(`${target} updated snapshot`, { claimId })
    const offerClaim = await this.repositories.offerClaims.findOneById(claimId)
    if (offerClaim) {
      try {
        const analyticsPayload = {
          event: 'CLAIM_ISSUED',
          properties: {
            destinationName: offerClaim.destinationName,
            rewardCash: offerClaim.rewardCash,
            rewardPoints: offerClaim.rewardPoints,
          },
          type: 'CLAIM_ISSUED',
          userId: userId.toString(),
        }
        const analytics = new Analytics(process.env.ANALYTICS_BUS_STREAM_NAME!, logger)
        await analytics.track(`Offer Claim Issued`, analyticsPayload)
      } catch (error) {
        const { message } = error
        logger.warn(`${target} ${message}`, { offerClaim })
      }
      logger.debug(`${target} event successful`, { offerClaim })
      // NOTE: we now send this from the event processor as we process 2 events (issued and inspected)
      // await this.putToTopic(context, this.transformModelToPayload(context, offerClaim))
    } else {
      logger.error(`${target} unable to issue claim not found`, { claimId })
    }
    return { event, offerClaim }
  }

  public async putToTopic(context: IContext, payload: IOfferClaimIssuedPayload) {
    const target = `${logTarget}putToTopic`
    const { logger } = context
    try {
      const eventTransport = new EventTransport(logger)
      logger.debug(`${target} pre-validate payload`, {
        payload,
      })
      const event = new OfferClaimIssued(payload)
      const emit: ISNSEmitParam = {
        attributes: [
          {
            dataType: 'String',
            key: 'OfferClaimType',
            value: payload.offer.type,
          },
        ],
        destination: EventDestinations.SNS,
        event,
        to: process.env.SNS_TOPIC_CLAIMS_MESSAGE!,
      }
      logger.debug(`${target} emitting...`, {
        emit,
      })
      await eventTransport.emit(emit)
      logger.debug(`${target} emitted`, { emit })
    } catch (error) {
      const { message } = error
      logger.error(`${target} ${message}`, { error })
      throw error
    }
  }

  public transformModelToPayload(context: IContext, offerClaim: OfferClaimDocument) {
    const target = `${logTarget}transformModelToPayload`
    const { logger } = context
    const required = {
      claimId: offerClaim._id,
      claimedDate: offerClaim.createdAt,
      expiresAt: offerClaim.expiresAt,
      destinationAddress: offerClaim.destinationAddress,
      destinationGeo: offerClaim.destinationGeo,
      destinationName: offerClaim.destinationName,
      inTerritory: offerClaim.inTerritory ?? true,
      isRedeemImmediately: offerClaim.isRedeemImmediately,
      isSandbox: offerClaim.isSandbox,
      offerId: offerClaim.offerId,
      rewardCash: offerClaim.rewardCash,
      rewardPoints: offerClaim.rewardPoints,
      userId: offerClaim.userId,
    }
    let payload
    switch (offerClaim.type) {
      case ClaimTypes.brandedAnywhere:
      case ClaimTypes.brandedHome:
      case ClaimTypes.brandedWork:
        payload = {
          ...required,
          offer: {
            campaign: offerClaim.campaign,
            googlePlaceId: offerClaim.googlePlaceId,
            googlePlace: offerClaim.googlePlace,
            type: offerClaim.type,
            status: offerClaim.status,
          },
        }
        break
      case ClaimTypes.brandedPartner:
        payload = {
          ...required,
          offer: {
            campaign: offerClaim.campaign,
            locationGeo: offerClaim.locationGeo,
            locationGroupId: offerClaim.locationGroupId,
            locationId: offerClaim.locationId,
            locationServiceFee: offerClaim.locationServiceFee,
            offerBudget: offerClaim.offerBudget,
            offerIsFreeTrial: offerClaim.offerIsFreeTrial,
            partnerId: offerClaim.partnerId,
            type: offerClaim.type,
            status: offerClaim.status,
          },
        }
        break
      case ClaimTypes.partnerPaid:
        payload = {
          ...required,
          offer: {
            locationGeo: offerClaim.locationGeo,
            locationGroupId: offerClaim.locationGroupId,
            locationId: offerClaim.locationId,
            locationServiceFee: offerClaim.locationServiceFee,
            offerBudget: offerClaim.offerBudget,
            offerIsFreeTrial: offerClaim.offerIsFreeTrial,
            partnerId: offerClaim.partnerId,
            type: offerClaim.type,
            status: offerClaim.status,
          },
        }
        break
      case ClaimTypes.partnerSubsidized:
        payload = {
          ...required,
          offer: {
            locationGeo: offerClaim.locationGeo,
            locationId: offerClaim.locationId,
            locationServiceFee: offerClaim.locationServiceFee,
            offerBudget: offerClaim.offerBudget,
            offerIsFreeTrial: offerClaim.offerIsFreeTrial,
            type: offerClaim.type,
            status: offerClaim.status,
          },
        }
        break
      case ClaimTypes.anywhere:
      case ClaimTypes.home:
      case ClaimTypes.work:
        payload = {
          ...required,
          offer: {
            googlePlaceId: offerClaim.googlePlaceId,
            googlePlace: offerClaim.googlePlace,
            type: offerClaim.type,
            status: offerClaim.status,
          },
        }
        break

      default:
        const message: never = offerClaim.type
        throw new TypeError(`${target} unknown type: ${message}`)
    }

    logger.debug(`${target} transformed outgoing payload`, {
      claimId: payload.claimId,
      offerClaim,
      payload: JSON.stringify(payload),
    })
    return payload
  }

  public generateObjectId({ count, year, day, month, hour, userId }) {
    const objectId = Crypto.createHash('md5')
      .update(`${userId}${count}${hour}${day}${month}${year}`)
      .digest('hex')
      .slice(0, 24)
      .toString()
    return Types.ObjectId(objectId)
  }

  private generateClaimIdAndExpiration(params: { count: number; userId: ObjectId }) {
    const { count, userId } = params
    const now = new Date()
    const expiresAt = new Date(now.getTime() + Expiration.inMilliseconds)
    const year = expiresAt.getFullYear()
    const month = expiresAt.getMonth()
    const day = expiresAt.getDate()
    const hoursIndexedByOne = expiresAt.getHours() + 1
    // round to every other hour to roll claims not expired, tripMatched or fulfilled to the same claim
    const hour = Math.ceil(hoursIndexedByOne / Expiration.inHours)
    const claimId = this.generateObjectId({
      year,
      day,
      month,
      hour,
      count,
      userId,
    })

    return {
      claimId,
      expiresAt,
    }
  }

  private async redeemVoucher(context: IContext, redeemParams: IRedeemVoucherRequestPayload) {
    const target = `${logTarget}redeemVoucher`
    const { logger } = context
    try {
      const request = new RedeemVoucherRequest(redeemParams)
      const params = {
        RequestContract: request,
        ResponseContract: RedeemVoucherResponse,
        FunctionName: process.env.REDEEM_VOUCHER_ARN!,
        Logger: logger,
      }
      const response = await invokeLambda<RedeemVoucherResponse>(params)
      return response
    } catch (error) {
      const { message } = error
      logger.warn(`${target} ${message}`, { error })
      throw error
    }
  }

  private async rollbackVoucher(context: IContext, rollbackParams: IRollbackVoucherRequestPayload) {
    const target = `${logTarget}rollbackVoucher`
    const { logger } = context
    try {
      const request = new RollbackVoucherRequest(rollbackParams)
      const params = {
        RequestContract: request,
        ResponseContract: RollbackVoucherResponse,
        FunctionName: process.env.ROLLBACK_VOUCHER_ARN!,
        Logger: logger,
      }
      const response = await invokeLambda<RollbackVoucherResponse>(params)
      return response
    } catch (error) {
      const { message } = error
      logger.warn(`${target} ${message}`, { error })
      throw error
    }
  }
}
