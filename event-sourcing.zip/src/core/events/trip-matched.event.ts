import { Analytics } from '@freebird/analytics-transport'
import {
  ClaimTypes,
  OfferClaimTripMatched,
  IOfferClaimTripMatchedPayload,
} from '@freebird/contracts-offer-claims'
import { OfferClaimEventTypes } from '@freebird/contracts-offer-claims'
import { ITripUpdatedPayload, TripStates } from '@freebird/contracts-trips'
import { EventDestinations, EventTransport, ISNSEmitParam } from '@freebird/event-transport'
import { Injectable } from '@nestjs/common'
import { OfferClaimDocument } from '../data/models'
import { RepositoryProvider, MatchingMeters, MatchingMetersAnywhere } from '../data/repositories'
import { IContext } from '../interfaces/context.interface'

const logTarget = 'claims:trip-matched: '

@Injectable()
export class OfferClaimTripMatchedEvent {
  constructor(private readonly repositories: RepositoryProvider) {}

  public async handle(context: IContext, payload: ITripUpdatedPayload) {
    const target = `${logTarget}handle`
    const { logger } = context
    // only attempt to match trips with a destinationGeo
    if (!payload.destinationGeo) {
      return
    }
    // match trip to claim
    const { destinationGeo, platform, tripId, userId } = payload
    let offerClaim = await this.repositories.offerClaims.findOneByTripAndUserId(context, {
      tripId,
      userId,
    })
    if (!offerClaim) {
      // NOTE: we first check claims to match trip within a tight 100 meters
      offerClaim = await this.repositories.offerClaims.findOneByDestinationGeo(context, {
        geo: destinationGeo,
        maxDistance: MatchingMeters,
        userId,
      })
      if (!offerClaim) {
        // NOTE: for claims to anywhere addresses we increase the matching radius
        // from 100 meters to 5 miles to give anywhere trips the benefit of the doubt
        // when changing their destination within the widened radius
        const conditions = {
          geo: destinationGeo,
          maxDistance: MatchingMetersAnywhere,
          type: { $in: [ClaimTypes.anywhere, ClaimTypes.home, ClaimTypes.work] },
          userId,
        }
        offerClaim = await this.repositories.offerClaims.findOneByDestinationGeo(
          context,
          conditions,
        )
        logger.debug(`${target} widening the search`, { conditions, offerClaim })
      }
    }
    const analyticsPayload = {
      event: 'CLAIM_TRIP_MATCHED',
      type: 'CLAIM_TRIP_MATCHED',
      properties: {},
      userId: userId.toString(),
    }
    const analytics = new Analytics(process.env.ANALYTICS_BUS_STREAM_NAME!, logger)
    logger.debug(`${target} analytics.track payload`, { analyticsPayload })
    const analyticsEventName = `${this.titleCase(platform)} ${
      payload.isReceiptReceived ? 'Receipt' : this.titleCase(payload.state.replace(/_/g, ' '))
    }`

    if (offerClaim) {
      try {
        await analytics.track(`Offer ${analyticsEventName}`, analyticsPayload)
      } catch (error) {
        const { message } = error
        logger.warn(`${target} ${message}`, { offerClaim })
      }
      const claimId = offerClaim._id
      logger.mergeContext({
        'x-claims-claim-id': claimId.toString(),
        'x-user-id': userId.toString(),
      })
      logger.debug(`${target} matched trip with claim`, { payload, offerClaim })

      const tripMatchedDate = new Date()
      const type = OfferClaimEventTypes.tripMatched
      const eventPayload = {
        claimId,
        payload,
        tripId,
        tripMatchedDate,
        tripPlatform: platform,
        userId,
      }
      const event = await this.repositories.offerClaimEvents.createEvent(
        context,
        eventPayload,
        type,
      )
      await this.repositories.offerClaimEvents.upsertSnapshot(context, claimId)
      offerClaim = await this.repositories.offerClaims.findOneById(claimId)
      const isDroppedOff = payload.state === TripStates.droppedoff
      const { isReceiptReceived } = payload
      if (offerClaim) {
        // notify services
        await this.putToTopic(context, this.transformModelToPayload(context, offerClaim))
      }
      return { event, offerClaim, isDroppedOff, isReceiptReceived }
    } else {
      logger.mergeContext({
        'x-user-id': userId.toString(),
      })
      logger.debug(`${target} unable to match claim not found`, { payload, offerClaim })
      try {
        await analytics.track(analyticsEventName, analyticsPayload)
      } catch (error) {
        const { message } = error
        logger.warn(`${target} ${message}`, { offerClaim })
      }
    }
  }

  public async putToTopic(context: IContext, payload: IOfferClaimTripMatchedPayload) {
    const target = `${logTarget}putToTopic`
    const { logger } = context
    try {
      const eventTransport = new EventTransport(logger)
      logger.debug(`${target} pre-validate payload`, {
        payload,
      })
      const event = new OfferClaimTripMatched(payload)
      const emit: ISNSEmitParam = {
        attributes: [
          {
            dataType: 'String',
            key: 'OfferClaimType',
            value: payload.offer.type,
          },
          {
            dataType: 'String',
            key: 'TripPlatform',
            value: payload.tripPlatform,
          },
          {
            dataType: 'String',
            key: 'TripState',
            value: payload.tripState,
          },
        ],
        destination: EventDestinations.SNS,
        event,
        to: process.env.SNS_TOPIC_CLAIMS_MESSAGE!,
      }
      logger.debug(`${target} emitting...`, {
        emit,
      })
      await eventTransport.emit(emit)
      logger.debug(`${target} emitted`, { emit, payload })
    } catch (error) {
      const { message } = error
      logger.error(`${target} ${message}`, { error })
      throw error
    }
  }

  private transformModelToPayload(context: IContext, offerClaim: OfferClaimDocument) {
    const target = `${logTarget}transformModelToPayload`
    const { logger } = context
    const required = {
      claimedDate: offerClaim.createdAt,
      claimId: offerClaim._id,
      destinationAddress: offerClaim.destinationAddress,
      destinationGeo: offerClaim.destinationGeo,
      destinationName: offerClaim.destinationName,
      expiresAt: offerClaim.expiresAt,
      inTerritory: offerClaim.inTerritory ?? true,
      isRedeemImmediately: offerClaim.isRedeemImmediately,
      isReceiptReceived: offerClaim.isReceiptReceived,
      isSandbox: offerClaim.isSandbox,
      offerId: offerClaim.offerId,
      rewardCash: offerClaim.rewardCash,
      rewardPoints: offerClaim.rewardPoints,
      tripId: offerClaim.tripId,
      tripMatchedDate: offerClaim.tripMatchedDate,
      tripPlatform: offerClaim.tripPlatform,
      tripState: offerClaim.tripState,
      userId: offerClaim.userId,
    }
    // let payload: IOfferClaimTripMatchedPayload
    let payload
    switch (offerClaim.type) {
      case ClaimTypes.brandedAnywhere:
      case ClaimTypes.brandedHome:
      case ClaimTypes.brandedWork:
        payload = {
          ...required,
          offer: {
            campaign: offerClaim.campaign,
            googlePlaceId: offerClaim.googlePlaceId,
            googlePlace: offerClaim.googlePlace,
            type: offerClaim.type,
            status: offerClaim.status,
          },
        }
        break
      case ClaimTypes.brandedPartner:
        payload = {
          ...required,
          offer: {
            campaign: offerClaim.campaign,
            locationGeo: offerClaim.locationGeo,
            locationGroupId: offerClaim.locationGroupId,
            locationId: offerClaim.locationId,
            locationServiceFee: offerClaim.locationServiceFee,
            offerBudget: offerClaim.offerBudget,
            offerIsFreeTrial: offerClaim.offerIsFreeTrial,
            partnerId: offerClaim.partnerId,
            type: offerClaim.type,
            status: offerClaim.status,
          },
        }
        break
      case ClaimTypes.partnerPaid:
        payload = {
          ...required,
          offer: {
            locationGeo: offerClaim.locationGeo,
            locationGroupId: offerClaim.locationGroupId,
            locationId: offerClaim.locationId,
            locationServiceFee: offerClaim.locationServiceFee,
            offerBudget: offerClaim.offerBudget,
            offerIsFreeTrial: offerClaim.offerIsFreeTrial,
            partnerId: offerClaim.partnerId,
            type: offerClaim.type,
            status: offerClaim.status,
          },
        }
        break
      case ClaimTypes.partnerSubsidized:
        payload = {
          ...required,
          offer: {
            locationGeo: offerClaim.locationGeo,
            locationId: offerClaim.locationId,
            locationServiceFee: offerClaim.locationServiceFee,
            offerBudget: offerClaim.offerBudget,
            offerIsFreeTrial: offerClaim.offerIsFreeTrial,
            type: offerClaim.type,
            status: offerClaim.status,
          },
        }
        break
      case ClaimTypes.anywhere:
      case ClaimTypes.home:
      case ClaimTypes.work:
        payload = {
          ...required,
          offer: {
            googlePlaceId: offerClaim.googlePlaceId,
            googlePlace: offerClaim.googlePlace,
            type: offerClaim.type,
            status: offerClaim.status,
          },
        }
        break

      default:
        const message: never = offerClaim.type
        throw new TypeError(`${target} unknown type: ${message}`)
    }

    logger.debug(`${target} transformed outgoing payload`, {
      claimId: payload.claimId,
      offerClaim,
      payload,
    })
    return payload
  }

  private titleCase(str: string) {
    const splitStr = str.toLowerCase().split(' ')
    for (let i = 0; i < splitStr.length; i++) {
      // You do not need to check if i is larger than splitStr length, as your for does that for you
      // Assign it back to the array
      splitStr[i] = splitStr[i].charAt(0).toUpperCase() + splitStr[i].substring(1)
    }
    // Directly return the joined string
    return splitStr.join(' ')
  }
}
