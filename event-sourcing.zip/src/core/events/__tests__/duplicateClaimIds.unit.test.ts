import { INestApplication } from '@nestjs/common'
import { Test } from '@nestjs/testing'
import { Types } from 'mongoose'
import intersection from 'lodash.intersection'
import { OfferClaimIssuedEvent } from '../issued.event'
import { setupApp, SERVICE_NAME } from '../../../http'
import { MongoMemoryReplSet } from 'mongodb-memory-server-global'
import { Connection } from 'mongoose'
import { MongoConfigService } from '../../data/mongo-config'
import { EventSourcingModule } from '../event-sourcing.module'

process.env.NO_TRACE = 'true'
process.env.EVENT_BUS_STREAM_NAME = 'mock-bus'
process.env.ANALYTICS_BUS_STREAM_NAME = 'mock-name'
process.env.EVENT_BUS_STREAM_ARN = 'mock-arn'
process.env.HAPI_TOPIC = 'mock-topic'
jasmine.DEFAULT_TIMEOUT_INTERVAL = 600000

type ObjectId = Types.ObjectId

describe(SERVICE_NAME, () => {
  let app: INestApplication
  let issuedEvent: OfferClaimIssuedEvent
  let mongoServer: MongoMemoryReplSet

  const mockMongoConfig = {
    async getConfig() {
      const mongoUri = await mongoServer.getConnectionString()
      // console.warn('mongoUri', mongoUri)
      return {
        useNewUrlParser: true,
        useUnifiedTopology: true,
        useCreateIndex: true,
        useFindAndModify: false,
        uri: mongoUri,
      }
    },
  }

  const ensureIndexes = async (nestApp: INestApplication) => {
    const connection: Connection = nestApp.get('DefaultTypegooseConnection')
    for (const modelName in connection.models) {
      if (connection.models.hasOwnProperty(modelName)) {
        const model = connection.models[modelName]
        await model.ensureIndexes()
      }
    }
  }

  beforeAll(async () => {
    mongoServer = new MongoMemoryReplSet({
      replSet: { storageEngine: 'wiredTiger' },
    })

    await mongoServer.waitUntilRunning()

    const module = await Test.createTestingModule({
      imports: [EventSourcingModule],
    })
      .overrideProvider(MongoConfigService)
      .useValue(mockMongoConfig)
      .compile()

    app = module.createNestApplication()
    setupApp(app)
    await app.init()

    issuedEvent = app.get(OfferClaimIssuedEvent)

    await ensureIndexes(app)
  })

  afterEach(async () => {
    jest.resetAllMocks()
    jest.restoreAllMocks()
  })

  afterAll(async () => {
    await app.close()
  })

  describe('Generate Mongo ObjectId for ClaimId', () => {
    test('generate two objectIds one week apart with no collisions', async () => {
      const createPayload = (params: { date: Date; userId: Types.ObjectId }) => {
        const { date, userId } = params
        const now = date
        const year = now.getFullYear()
        const month = now.getMonth()
        const day = now.getDate()
        const hour = now.getHours()
        return {
          count: 0,
          year,
          month,
          day,
          hour,
          userId,
        }
      }
      const today = new Date()
      const payloadA = createPayload({
        date: today,
        userId: Types.ObjectId('5dbb43dfc7e979eac476680b'),
      })
      const claimIdA = issuedEvent.generateObjectId(payloadA)
      const oneWeekFromToday = new Date()
      oneWeekFromToday.setDate(today.getDate() + 7)
      const payloadB = createPayload({
        date: oneWeekFromToday,
        userId: Types.ObjectId('5dbb43dfc7e979eac476680b'),
      })
      const claimIdB = issuedEvent.generateObjectId(payloadB)
      expect(claimIdA.toString()).not.toEqual(claimIdB.toString())
    })

    test('generate objectIds with no collisions', async () => {
      const users = [
        '598472d6710880a8e787b07e',
        '598472d6710880a8e787b07f',
        '598472d6710880a8e787b07d',
        '498472d6710880a8e787b07d',
        '698472d6710880a8e787b07d',
      ]
      const offers = [
        '598472d6710560a8e787b07d',
        '598472d6710560a8e787b07e',
        '598472d6710560a8e787b07f',
        '698472d6710560a8e787b07e',
        '498472d6710560a8e787b07e',
      ]
      const now = new Date()
      const nowYear = now.getFullYear()
      const nowMonth = now.getMonth()
      const nowDay = now.getDate()
      const nowHour = now.getHours()
      const objectIds: ObjectId[] = []
      users.map(userId =>
        offers.map(_offerId => {
          const years = [nowYear, nowYear - 1, nowYear + 1]
          const months = [nowMonth, Math.max(nowMonth - 1, 0), Math.min(nowMonth + 1, 11)]
          const days = [nowDay, Math.max(nowDay - 1, 0), Math.min(nowDay + 1, 30)]
          const hours = [nowHour, Math.max(nowHour - 1, 0), Math.min(nowHour + 1, 23)]
          return years.map(year =>
            months.map(month =>
              days.map(day =>
                hours.map(hour => {
                  const payload = {
                    count: 0,
                    year,
                    month,
                    day,
                    hour,
                    userId,
                  }
                  const oid = issuedEvent.generateObjectId(payload)
                  objectIds.push(oid)
                  return oid
                }),
              ),
            ),
          )
        }),
      )

      const objectId = issuedEvent.generateObjectId({
        count: 0,
        year: nowYear,
        month: nowMonth,
        day: nowDay,
        hour: nowHour,
        userId: users[0],
      })

      const difference = intersection(objectIds, [objectId])
      expect(difference.length).toEqual(0)
    })
  })
})
