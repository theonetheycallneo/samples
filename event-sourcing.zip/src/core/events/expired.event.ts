import { Analytics } from '@freebird/analytics-transport'
import {
  IOfferClaimExpiredPayload,
  OfferClaimExpired,
  OfferClaimEventTypes,
} from '@freebird/contracts-offer-claims'
import { EventDestinations, EventTransport, ISNSEmitParam } from '@freebird/event-transport'
import { Injectable, NotFoundException } from '@nestjs/common'
import { IContext } from '../interfaces/context.interface'
import { OfferClaimDocument } from '../data/models'
import { RepositoryProvider, IOfferClaimExpiredEventParameters } from '../data/repositories'

const logTarget = 'claims:expired: '

@Injectable()
export class OfferClaimExpiredEvent {
  constructor(private readonly repositories: RepositoryProvider) {}

  public async handle(context: IContext, payload: IOfferClaimExpiredEventParameters) {
    const target = `${logTarget}handle`
    const { logger } = context
    const { claimId } = payload
    logger.debug(`${target} findOneById`, { claimId })
    const claim = await this.repositories.offerClaims.findOneById(claimId)
    if (claim) {
      const type = OfferClaimEventTypes.expired
      logger.debug(`${target} createEvent`, { claimId, type })
      const event = await this.repositories.offerClaimEvents.createEvent(context, payload, type)
      await this.repositories.offerClaimEvents.upsertSnapshot(context, claimId)
      const offerClaim = await this.repositories.offerClaims.findOneById(claimId)
      logger.debug(`${target} updated snapshot`, { claimId, offerClaim })
      if (offerClaim) {
        try {
          const analyticsPayload = {
            event: 'CLAIM_EXPIRED',
            properties: {
              destinationName: claim.destinationName,
              rewardCash: claim.rewardCash,
              rewardPoints: claim.rewardPoints,
            },
            type: 'CLAIM_EXPIRED',
            userId: claim.userId.toString(),
          }
          const analytics = new Analytics(process.env.ANALYTICS_BUS_STREAM_NAME!, logger)
          await analytics.track(`Offer Claim Expired`, analyticsPayload)
        } catch (error) {
          const { message } = error
          logger.warn(`${target} ${message}`, { offerClaim })
        }
        logger.debug(`${target} event successful`, { offerClaim })
        await this.putToTopic(context, this.transformModelToPayload(context, offerClaim))
      } else {
        logger.error(`${target} unable to expire claim not found`, { claimId })
      }
      return { event, offerClaim }
    }
    throw new NotFoundException('OfferClaim not found')
  }

  public async putToTopic(context: IContext, payload: IOfferClaimExpiredPayload) {
    const target = `${logTarget}putToTopic`
    const { logger } = context
    try {
      const eventTransport = new EventTransport(logger)
      logger.debug(`${target} pre-validate payload`, {
        payload,
      })
      const event = new OfferClaimExpired(payload)
      const emit: ISNSEmitParam = {
        attributes: [
          {
            dataType: 'String',
            key: 'HasVoucherRedemption',
            value: payload.voucherRedemptionId ? 'hasVoucherRedemption' : 'none',
          },
        ],
        destination: EventDestinations.SNS,
        event,
        to: process.env.SNS_TOPIC_CLAIMS_MESSAGE!,
      }
      logger.debug(`${target} emitting...`, {
        emit,
      })
      await eventTransport.emit(emit)
      logger.debug(`${target} emitted`, { emit, payload })
    } catch (error) {
      const { message } = error
      logger.error(`${target} ${message}`, { error })
      throw error
    }
  }

  private transformModelToPayload(context: IContext, offerClaim: OfferClaimDocument) {
    const target = `${logTarget}transformModelToPayload`
    const { logger } = context
    const payload = {
      claimId: offerClaim._id,
      expiresAt: offerClaim.expiresAt,
      isSandbox: offerClaim.isSandbox,
      userId: offerClaim.userId,
      voucherRedemptionId: offerClaim.voucherRedemptionId,
    }
    logger.debug(`${target} transformed outgoing payload`, {
      claimId: payload.claimId,
      offerClaim,
      payload,
    })
    return payload
  }
}
