import { Analytics } from '@freebird/analytics-transport'
import { EventTransport, EventDestinations, ISNSEmitParam } from '@freebird/event-transport'
import {
  ClaimTypes,
  OfferClaimFulfilled,
  IOfferClaimFulfilledPayload,
  OfferClaimEventTypes,
} from '@freebird/contracts-offer-claims'
import { Injectable } from '@nestjs/common'
import { IContext } from '../interfaces/context.interface'
import { OfferClaimDocument } from '../data/models'
import { RepositoryProvider, IOfferClaimFulfilledEventParameters } from '../data/repositories'

const logTarget = 'claims:fulfilled: '

@Injectable()
export class OfferClaimFulfilledEvent {
  constructor(private readonly repositories: RepositoryProvider) {}

  public async handle(context: IContext, payload: IOfferClaimFulfilledEventParameters) {
    const target = `${logTarget}handle`
    const { logger } = context
    const { claimId } = payload
    const eventPayload = { ...payload, claimId }
    const unfulfilled = await this.repositories.offerClaims.findOneCompletedTripMatchedById({
      claimId,
    })
    logger.mergeContext({
      'x-claims-claim-id': claimId.toString(),
    })
    if (unfulfilled) {
      logger.mergeContext({
        'x-user-id': unfulfilled.userId.toString(),
      })
      const type = OfferClaimEventTypes.fulfilled
      const event = await this.repositories.offerClaimEvents.createEvent(
        context,
        eventPayload,
        type,
      )
      await this.repositories.offerClaimEvents.upsertSnapshot(context, claimId)
      logger.debug(`${target} updated claim snapshot`, { claimId })
      const offerClaim = await this.repositories.offerClaims.findOneById(claimId)
      if (offerClaim) {
        try {
          const analyticsPayload = {
            event: 'CLAIM_FULFILLED',
            properties: {
              claimType: offerClaim.type,
              destinationName: offerClaim.destinationName,
              rewardCash: offerClaim.rewardCash,
              rewardPoints: offerClaim.rewardPoints,
              ...([
                ClaimTypes.brandedAnywhere,
                ClaimTypes.brandedHome,
                ClaimTypes.brandedPartner,
                ClaimTypes.brandedWork,
              ].includes(offerClaim.type)
                ? {
                    sponsor:
                      offerClaim.campaign && offerClaim.campaign.name
                        ? offerClaim.campaign.name
                        : '',
                  }
                : null),
            },
            type: 'CLAIM_FULFILLED',
            userId: unfulfilled.userId.toString(),
          }
          const analytics = new Analytics(process.env.ANALYTICS_BUS_STREAM_NAME!, logger)
          logger.debug(`${target} analytics.track payload`, { analyticsPayload })
          await analytics.track(`Offer Claim Fulfilled`, analyticsPayload)
        } catch (error) {
          const { message } = error
          logger.warn(`${target} ${message}`, { offerClaim })
        }
        await this.repositories.offerClaims.upsertUserSnapshot(context, offerClaim.userId)
        logger.debug(`${target} updated user snapshot`, { offerClaim })
        await this.putToTopic(context, this.transformModelToPayload(context, offerClaim))
      } else {
        logger.error(
          `${target} unable to update user snapshot and emit fulfilled claim not found`,
          {
            claimId,
            unfulfilled,
          },
        )
      }
      return { event, offerClaim }
    }
    logger.warn(`${target} unable to fulfill claim not found`, {
      claimId,
      payload,
    })
  }

  public async putToTopic(context: IContext, payload: IOfferClaimFulfilledPayload) {
    const target = `${logTarget}putToTopic`
    const { logger } = context
    try {
      const eventTransport = new EventTransport(logger)
      logger.debug(`${target} pre-validate payload`, {
        payload,
      })
      const event = new OfferClaimFulfilled(payload)
      const emit: ISNSEmitParam = {
        attributes: [
          {
            dataType: 'String',
            key: 'InTerritory',
            value: payload.inTerritory ? 'inTerritory' : 'notInTerritory',
          },
          {
            dataType: 'String',
            key: 'HasVoucherRedemption',
            value: payload.voucherRedemptionId ? 'hasVoucherRedemption' : 'none',
          },
          {
            dataType: 'String',
            key: 'OfferClaimType',
            value: payload.offer.type,
          },
        ],
        destination: EventDestinations.SNS,
        event,
        to: process.env.SNS_TOPIC_CLAIMS_MESSAGE!,
      }
      logger.debug(`${target} emitting...`, {
        emit,
      })
      await eventTransport.emit(emit)
      logger.debug(`${target} emitted`, { emit, payload })
    } catch (error) {
      const { message } = error
      logger.error(`${target} ${message}`, { error })
      throw error
    }
  }

  private transformModelToPayload(context: IContext, offerClaim: OfferClaimDocument) {
    const target = `${logTarget}transformModelToPayload`
    const { logger } = context
    const required = {
      claimedDate: offerClaim.createdAt,
      claimId: offerClaim._id,
      destinationAddress: offerClaim.destinationAddress,
      destinationGeo: offerClaim.destinationGeo,
      destinationName: offerClaim.destinationName,
      expiresAt: offerClaim.expiresAt,
      inTerritory: offerClaim.inTerritory ?? true,
      isReceiptReceived: offerClaim.isReceiptReceived,
      isRedeemImmediately: offerClaim.isRedeemImmediately,
      isSandbox: offerClaim.isSandbox,
      offerId: offerClaim.offerId,
      pickupGeo: offerClaim.pickupGeo,
      rewardCash: offerClaim.rewardCash,
      rewardPoints: offerClaim.rewardPoints,
      tripId: offerClaim.tripId,
      tripMatchedDate: offerClaim.tripMatchedDate,
      tripPlatform: offerClaim.tripPlatform,
      tripState: offerClaim.tripState,
      userId: offerClaim.userId,
      voucherRedemptionId: offerClaim.voucherRedemptionId,
    }
    let payload
    switch (offerClaim.type) {
      case ClaimTypes.brandedAnywhere:
      case ClaimTypes.brandedHome:
      case ClaimTypes.brandedWork:
        payload = {
          ...required,
          offer: {
            campaign: offerClaim.campaign,
            googlePlaceId: offerClaim.googlePlaceId,
            googlePlace: offerClaim.googlePlace,
            type: offerClaim.type,
            status: offerClaim.status,
          },
        }
        break
      case ClaimTypes.brandedPartner:
        payload = {
          ...required,
          offer: {
            campaign: offerClaim.campaign,
            locationGeo: offerClaim.locationGeo,
            locationGroupId: offerClaim.locationGroupId,
            locationId: offerClaim.locationId,
            locationServiceFee: offerClaim.locationServiceFee,
            offerBudget: offerClaim.offerBudget,
            offerIsFreeTrial: offerClaim.offerIsFreeTrial,
            partnerId: offerClaim.partnerId,
            type: offerClaim.type,
            status: offerClaim.status,
          },
          transactionId: offerClaim.transactionId,
          transactionAmount: offerClaim.transactionAmount,
        }
        break
      case ClaimTypes.partnerPaid:
        payload = {
          ...required,
          offer: {
            locationGeo: offerClaim.locationGeo,
            locationGroupId: offerClaim.locationGroupId,
            locationId: offerClaim.locationId,
            locationServiceFee: offerClaim.locationServiceFee,
            offerBudget: offerClaim.offerBudget,
            offerIsFreeTrial: offerClaim.offerIsFreeTrial,
            partnerId: offerClaim.partnerId,
            type: offerClaim.type,
            status: offerClaim.status,
          },
          transactionId: offerClaim.transactionId,
          transactionAmount: offerClaim.transactionAmount,
        }
        break
      case ClaimTypes.partnerSubsidized:
        payload = {
          ...required,
          offer: {
            locationGeo: offerClaim.locationGeo,
            locationId: offerClaim.locationId,
            locationServiceFee: offerClaim.locationServiceFee,
            offerBudget: offerClaim.offerBudget,
            offerIsFreeTrial: offerClaim.offerIsFreeTrial,
            type: offerClaim.type,
            status: offerClaim.status,
          },
          transactionId: offerClaim.transactionId,
          transactionAmount: offerClaim.transactionAmount,
        }
        break
      case ClaimTypes.anywhere:
      case ClaimTypes.home:
      case ClaimTypes.work:
        payload = {
          ...required,
          offer: {
            googlePlaceId: offerClaim.googlePlaceId,
            googlePlace: offerClaim.googlePlace,
            type: offerClaim.type,
            status: offerClaim.status,
          },
        }
        break

      default:
        const message: never = offerClaim.type
        throw new TypeError(`${target} unknown type: ${message}`)
    }

    logger.debug(`${target} transformed outgoing payload`, {
      claimId: payload.claimId,
      offerClaim,
      payload,
    })
    return payload
  }
}
