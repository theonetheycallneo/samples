import { Injectable } from '@nestjs/common'
import { OfferClaimIssuedEvent } from './issued.event'
import { OfferClaimTripMatchedEvent } from './trip-matched.event'
import { OfferClaimFulfilledEvent } from './fulfilled.event'
import { OfferClaimExpiredEvent } from './expired.event'
import { OfferClaimUnexpiredEvent } from './unexpired.event'
import { OfferClaimInspectedEvent } from './inspected.event'

export const Events = [
  OfferClaimIssuedEvent,
  OfferClaimInspectedEvent,
  OfferClaimTripMatchedEvent,
  OfferClaimFulfilledEvent,
  OfferClaimExpiredEvent,
  OfferClaimUnexpiredEvent,
]

@Injectable()
export class EventHandlerProvider {
  constructor(
    public readonly issued: OfferClaimIssuedEvent,
    public readonly inspected: OfferClaimInspectedEvent,
    public readonly tripMatched: OfferClaimTripMatchedEvent,
    public readonly fulfilled: OfferClaimFulfilledEvent,
    public readonly expired: OfferClaimExpiredEvent,
    public readonly unexpired: OfferClaimUnexpiredEvent,
  ) {}
}
