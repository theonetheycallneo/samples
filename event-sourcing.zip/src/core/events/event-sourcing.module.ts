import { Module } from '@nestjs/common'
import { EventHandlerProvider, Events } from './index'
import { DataModule } from '../data/data.module'
import { EventProcessor } from './event-processor'

const providers = [...Events, EventHandlerProvider, EventProcessor]

@Module({
  controllers: [],
  imports: [DataModule],
  exports: providers,
  providers,
})
export class EventSourcingModule {}
