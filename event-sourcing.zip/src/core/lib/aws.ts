import AWS from 'aws-sdk'
import AWSXRay from 'aws-xray-sdk'

export const tracingEnabled = () => {
  return !process.env.IS_OFFLINE && !process.env.NO_TRACE && !process.env.IS_LOCAL
}

export const getSNSClient = () => {
  const sns = new AWS.SNS()
  return tracingEnabled() ? AWSXRay.captureAWSClient(sns) : sns
}

export const publishMessageToTopic = async (Message: string) => {
  const TopicArn = process.env.HAPI_TOPIC
  const sns = getSNSClient()
  await sns
    .publish({
      TopicArn,
      MessageStructure: '',
      Message,
    })
    .promise()
}
